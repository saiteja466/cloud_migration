export interface Scores{
    scoreId:number;
    applicationComplexity:string;
    applicationData:string;
    score:string
}