import { Component, OnInit } from '@angular/core';
import { Parameter } from '../Parameter';
import { ParameterService } from '../Service/parameter.service';
import { ConfirmationService, Message, MessageService } from 'primeng/api';

@Component({
  selector: 'app-parameter',
  templateUrl: './parameter.component.html',
  providers: [MessageService,ConfirmationService],
  styleUrls: ['./parameter.component.scss']
})
export class ParameterComponent implements OnInit {

  parameters:any;
  param:Parameter[]=[];
 
  parameter:Parameter[];
  totalRecords:any;
  first: number = 0;
  page: number;
  rows: number = 10;
  cols:any;
  submitted: boolean;
  parameterDialog: boolean;
  cloneParameter: { [s: string]: Parameter; } = {};
 
  deleteRecord: any;
  allCategory: any;
  allparameter: any;
  allParameters: {}[];
  serverSize: any[];
  typeData: any[];
  allInterfaces: any;
  allhardwareNeed: { label: string; value: string; }[];
  allComplianceNeed: { label: string; value: string; }[];
  allLoadBalancer: { label: string; value: string; }[];
  allAppComponent: { label: string; value: string; }[];
  BusinessCriticality: { label: string; value: string; }[];
  allDatabaseSize: { label: string; value: string; }[];
  allDbObject: { label: string; value: string; }[];
  allDB: { label: string; value: string; }[];
  allLoc: { label: string; value: string; }[];
  applyTypeData: { label: string; value: string; }[];
  message: string;
  editedRecords: Parameter[];
  
  constructor(private parameterService:ParameterService, private confirmationService: ConfirmationService, private messageService:MessageService) { }

  ngOnInit(){

    this.cols=[
      { field: 'parameterId', header: 'Parameter ID'},
      { field: 'category', header: 'Category'},
      { field: 'parameters', header: 'Parameters'},
      { field: 'serverCount', header: 'No Of Server'},
      { field: 'interfaces', header: 'Interfaces'},
      { field: 'loc', header: 'Line Of Code'},
      { field: 'db', header: 'DB'},
      { field: 'dbObject', header: 'DB Object'},
      { field: 'databaseSize', header: 'Database Size'},
      { field: 'businessCriticality', header: 'Business Criticality'},
      { field: 'appComponent', header: 'App Component'},
      { field: 'loadBalancer', header: 'Load Balancer'},
      { field: 'compilanceNeed', header: 'Compilance Need'},
      { field: 'specialHardwareNeed', header: 'Special Hardware Need'},
      { field: 'tshirtSize', header: 'T Shirt Size'},
      { field: 'applyType', header: 'Apply Type'}
    ],

    this.allCategory = [
      {label: 'Application Complexity', value: 'Application Complexity'},
      {label: 'Database Statistics', value: 'Database Statistics'},
      {label: 'Business Revelance', value: 'Business Revelance'},
      {label: 'Application Type', value: 'Application Type'}
      
  ],

  this.serverSize = [
    { label: '1-6', value: '1-6'},
    { label: '6-20', value: '6-20'},
    { label: '<20', value: '<20'},
    { label: '>20', value: '>20'}
    ],

  this.allParameters =[
    { label: 'Server count', value: 'Server count'},
    { label: 'Appl Type', value: 'Appl Type'},
    { label: 'Interfaces', value: 'Interfaces'},
    { label: 'LOC', value: 'LOC'}
  
  ],

  this.applyTypeData =[
    { label: 'CUSTOM', value: 'CUSTOM'},
    { label: 'COTS', value: 'COTS'},
    { label: 'BUILD', value: 'BUILD'}
    ],

  this.allInterfaces =[
    { label: '<5', value: '<5'},
    { label: '5-10', value: '5-10'},
    { label: '>10', value: '>10'},
    { label: '<20', value: '<20'}
  ],

  this.allLoc =[
    { label: '<50000', value: '<50000'},
    { label: '<500000', value: '<500000'},
    { label: '<1000000', value: '<1000000'}
  ],

  this.allDB =[
    { label: 'DB2', value: 'DB2'},
    { label: 'MSSQL', value: 'MSSQL'},
    { label: 'Between 500 to 2TB', value: 'Between 500 to 2TB'},
    { label: 'MSSQL', value: 'MSSQL'},
    { label: 'MongoDB', value: 'MongoDB'},
    { label: 'MYSQL', value: 'MYSQL'},
    { label: 'Oracle', value: 'Oracle'},
    { label: 'Postgre', value: 'Postgre'},
    { label: 'Sybase', value: 'Sybase'},
  ],

  this.allDbObject =[
    { label: '<5', value: '<5'},
    { label: '5-15', value: '5-15'},
    { label: '<35', value: '<35'}
  ],

  this.allDatabaseSize =[
    { label: '<100 GB', value: '<100 GB'},
    { label: '<500 GB', value: '<500 GB'},
    { label: '<2 TB', value: '<2 TB'}
  ],

  this.BusinessCriticality =[
    { label: 'Low Critical', value: 'Low Critical'},
    { label: 'Medium', value: 'Medium'},
    { label: 'High Critical', value: 'High Critical'}
  ],

  this.allAppComponent =[
    { label: 'Frontend only', value: 'Frontend only'},
    { label: 'Backend only', value: 'Backend only'}
  ],

  this.allLoadBalancer =[
    { label: 'No HA/LB', value: 'No HA/LB'},
    { label: 'HA_ONLY OR LB_ONLY', value: 'HA_ONLY OR LB_ONLY'},
    { label: 'HA_LB', value: 'HA_LB'}
  ],

  this.allComplianceNeed =[
    { label: 'Yes', value: 'Yes'},
    { label: 'No', value: 'No'}
  ],

  this.allhardwareNeed =[
    { label: 'Yes', value: 'Yes'},
    { label: 'No', value: 'No'}
  ],


    this.parameterService.getAllParameter().subscribe(data=>{
      console.log("data",data);
      this.parameters=data;
      this.totalRecords=data.length;
    })
  }

  getAllParameter() {
    this.parameterService.getAllParameter().subscribe(data=>(data));
    
  }
 
  editParameter(parameter:any){
    
    this.parameterService.editParameter(parameter).subscribe(data=>{alert(data)});
  }

  onRowEditInit(parameter:any){
    this.submitted = false;
    this.cloneParameter[parameter.parameterId] = {...parameter};
    
    
  }

  onRowEditSave(parameter:any) {
    this.submitted = true;
    this.editParameter(parameter);
    console.log(parameter);
  }

  onRowEditCancel(parameter:any, ri:number){
    this.editedRecords=this.parameters;
    
    this.editedRecords[ri] = this.cloneParameter[parameter.parameterId];
    delete this.cloneParameter[parameter.parameterId];
  
  }

  deleteParameter(parameter:any){
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteRecord = parameter;
        this.parameterService.deleteParameterById(this.deleteRecord.parameterId).subscribe(
    
          (data: any) => {
            console.log(data);
            this.getAllParameter();
             
          });
        
          this.messageService.add({severity:'success', summary: 'Success', detail:' Parameter deleted'});

      },

      reject: () => {
        this.confirmationService.close()
    }
      
  }); 
   
  }

  hideDialog() {
    this.parameterDialog = false;
  }

  openDialouge() { 
   
    this.submitted = false;
    this.parameterDialog = true;
}

  saveParameter(parameters:any) {
    let reqParam={
      "category": parameters.category,
      "parameters": parameters.parameter,
      "serverCount": parameters.serverCount,
      "interfaces": parameters.interfaces,
      "loc": parameters.loc,
      "db": parameters.db,
      "dbObject": parameters.dbObject,
      "databaseSize": parameters.databaseSize,
      "businessCriticality": parameters.businessCriticality,
      "appcomponent": parameters.appComponent,
      "loadBalancer": parameters.loadBalancer,
      "complianceNeed": parameters.complianceNeed,
      "specialhardwareNeed": parameters.specialhardwareNeed,
      "applyType": parameters.applyType
    }
    
    console.log("reqari params---",reqParam);
    
    this.parameterService.addParameter(reqParam).subscribe(
      (data: any) => {
        console.log(data);
        this.getAllParameter();
      });
      this.messageService.add({severity:'success', summary: 'Parameter Added', detail:this.message});
      this.parameterDialog= false;

  }

  categoryData() {

    if(this.parameters.category == "Application Complexity") {
      console.log("drop dwon ");
      this.allparameter=[
      { label: 'Server count', value: 'Server count'},
      { label: 'Appl Type', value: 'Appl Type'},
      { label: 'Interfaces', value: 'Interfaces'},
      { label: 'LOC', value: 'LOC'}
    ];
    }

    else if(this.parameters.category == "Database Statistics") {
     
      this.allparameter=[
      { label: 'DB', value: 'DB'},
      { label: 'DB objects', value: 'DB objects'},
      { label: 'Database size', value: 'Database size'},
      
    ];
    }

    else if(this.parameters.category == "Business Revelance") {
     
      this.allparameter=[
      { label: 'Business Criticality', value: 'Business Criticality'},
      
    ];
    }

   else if(this.parameters.category == "Application Type") {

      this.allparameter=[
      { label: 'App component', value: 'App component'},
      { label: 'Load balancer', value: 'Load balancer'},
      { label: 'Compliance needs', value: 'Compliance needs'},
      { label: 'Special hardware required', value: 'Special hardware required'}
    ];
    }
    else{
      this.parameters.category =null;
    }

  }

  parameterData() {
  }
}
