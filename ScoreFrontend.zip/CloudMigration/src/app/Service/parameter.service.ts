import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ParameterService {

  constructor(private http:HttpClient) { }

  getAllParameter():Observable<any> {
    console.log("service");
    return this.http.get<any>("http://localhost:6869/getAllParameters");
  }

  deleteParameterById(id:number) {
    return this.http.delete("http://localhost:6869/deleteParameter"+'/'+id);
}

public editParameter(parameter:any){
  return this.http.put("http://localhost:6869/addParameter", parameter, {responseType:'text'});
  
}

public addParameter(parameters:any) {
  console.log(parameters);
  
  return this.http.post("http://localhost:6869/addParameter",parameters, {responseType:'text'});
}
}
