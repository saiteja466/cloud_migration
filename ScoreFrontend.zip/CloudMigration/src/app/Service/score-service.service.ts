import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {map} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ScoreServiceService {

  

  constructor(private http:HttpClient) { }

  getAllScore():Observable<any> {
    console.log("service");
    return this.http.get<any>("http://localhost:6869/getAllScore");
  }

  getScoreById(id:number) {
      return this.http.get("http://localhost:6869/getScoreById/"+id);
  }

  addScore(reqParam) {
    console.log("add service");
    
    return this.http.post<any>("http://localhost:6869/addScore" ,reqParam)
    .pipe(map((res:any)=>{
      console.log(res.responseType.text);
      return res.headers;
    }));
  }

  public editScore(score:any){
    return this.http.put("http://localhost:6869/editScore", score[0], {responseType:'text'});
    
  }

  deleteScoreById(id:string) {
    return this.http.delete("http://localhost:6869/deleteScoreById"+'/'+id,  {responseType:'text'});
}

}
