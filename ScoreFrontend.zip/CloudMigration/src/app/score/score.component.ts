import { flatten, ThisReceiver, ThrowStmt } from '@angular/compiler';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ConfirmationService,  MessageService } from 'primeng/api';

import { Scores } from '../Scores';
import { ScoreServiceService } from '../Service/score-service.service';



@Component({
  selector: 'app-score',
  templateUrl: './score.component.html',
  styleUrls: ['./score.component.scss'],
  providers: [MessageService,ConfirmationService]
})
export class ScoreComponent implements OnInit {

  scores:Scores[]=[];
  
  allComplexity:any;
  allData:any;
  score:Scores[];
  totalRecords:any;
  first: number = 0;
  page: number;
  rows: number = 10;
  cols:any;
  submitted: boolean;
  scoreDialog: boolean;
  cloneScore: { [s: string]: Scores; } = {};
  complexityAddValue:any;
  dataAddValue:any;
  scoreAddValue:any;
  modalRef: BsModalRef;
  deleteRecord: any;
  deleteDi: boolean;
  editedRecords:Scores[];
  idToBeDeleted = '';
  message: string;
  constructor(private scoreService: ScoreServiceService,private modalService: BsModalService,
     private confirmationService: ConfirmationService,private messageService: MessageService) { 

  }

  ngOnInit() {
    this.cols=[
      { field: 'scoreId', header: 'Score ID'},
      { field: 'applicationComplexity', header: 'Application Complexity'},
      { field: 'applicationData', header: 'Application Data'},
      { field: 'score', header: 'Score'}

    ];

    
      this.allComplexity = [
        {label: 'No of Interfaces', value: 'No of Interfaces'},
        {label: 'HA/LB', value: 'HA/LB'},
        {label: 'Application Type', value: 'Application Type'},
        {label: 'App Component', value: 'App Component'},
        {label: 'LOC', value: 'LOC'},
        {label: 'Business Criticality', value: 'Business Criticality'},
        {label: 'Prod Servers', value: 'Prod Servers'},
        {label: 'Database Size', value: 'Database Size'},
        {label: 'Database', value: 'Database'},
        {label: 'DatabaseMigrationType', value: 'DatabaseMigrationType'},
        {label: 'Contigency', value: 'Contigency'},
        {label: 'T Shirt Size', value: 'T Shirt Size'},
        {label: 'Migration Type', value: 'Migration Type'}
    ]

    console.log("score component");
    this.scoreService.getAllScore().subscribe(data=>{
      console.log("data",data);
      this.scores=data;
      this.totalRecords=data.length;
    })
  }

  getAllScores() { 
    this.scoreService.getAllScore().subscribe(data=>{
      console.log("data",data);
      this.scores=data;
      this.totalRecords=data.length;
    })
  }

  newRow() {
    return { scoreId: '', applicationComplexity: '', applicationData: '', score: '' };
  }
 
  editScore(score:any){
    console.log(score);
    
    this.scoreService.editScore(this.scores).subscribe(data=>{alert(data)});
    
  }

  onRowEditInit(score:any){
    
    this.cloneScore[score.scoreId] = {...score};
    console.log(score);
    
    
  }

  onRowEditSave(score:any) {
    
    this.submitted = true;
    this.editScore(score);
    console.log(score);
  }

  onRowEditCancel(score:any, ri:number){
    this.editedRecords=this.scores;
    
    this.editedRecords[ri] = this.cloneScore[score.scoreId];
    delete this.cloneScore[score.scoreId];
  
  }

  cancelDilouge() {
    this.deleteDi= false;
  }

  openModal(template: TemplateRef<any>, id: any) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    this.idToBeDeleted = id;
    console.log(id);
    
  }
  confirm(): void {
    this.message = 'Deleted';
    this.modalRef.hide();
    this.deleteScore();
  }

  

  decline(): void {
    this.message = 'Declined!';
    this.modalRef.hide();
    this.messageService.add({severity:'error', summary: 'Declined', detail:this.message});

  }
  deleteScore(){
   
    //console.log(score);
   
        this.scoreService.deleteScoreById(this.idToBeDeleted).subscribe(
    
          (data: any) => {
            console.log(data);
            this.messageService.add({severity:'success', summary: 'Deleted', detail:this.message});
             this.getAllScores();
          });
  }

  hideDialog() {
    this.scoreDialog = false;
    this.submitted = false;

  }

  openDialouge() { 
    this.submitted = false;
    this.scoreDialog = true;
    console.log("new");
    this.complexityAddValue= null;
    this.dataAddValue = null
    this.scoreAddValue = null
    
}

  saveScore() {
   

    debugger
    console.log("datat sjdjh",this.complexityAddValue);
    
    this.submitted = true;
   if((this.complexityAddValue !=null || this.complexityAddValue != undefined )
      || (this.dataAddValue != null || this.dataAddValue != undefined)
      || (this.scoreAddValue != null || this.scoreAddValue != undefined )) {
      
      let reqParam={
        "applicationComplexity": this.complexityAddValue,
        "applicationData":this.dataAddValue,
        "score": this.scoreAddValue
      }
      this.scoreService.addScore(reqParam).subscribe(
        (data: any) => {
          console.log(data);
          this.getAllScores();
        });
        this.messageService.add({severity:'success', summary: 'Score Added', detail:this.message});
        this.scoreDialog= false;
        this.getAllScores();
        
    }
     

  
  }

  complexityData() {
  
    if(this.complexityAddValue == "No of Interfaces"){
      this.allData=[
      { label: 'Less than 5', value: 'Less than 5'},
      { label: 'Between 6 and 10', value: 'Between 6 and 10'},
      { label: 'More than 10', value: 'More than 10'}
    ];
    }

    else if(this.complexityAddValue == "HA/LB"){
      this.allData=[
      { label: 'No HA/LB', value: 'No HA/LB'},
      { label: 'HA Only or LB Only', value: 'HA Only or LB Only'},
      { label: 'HA and LB', value: 'HA and LB'}
    ];
    }

    else if(this.complexityAddValue  == "Application Type"){
      this.allData=[
      { label: 'COTS', value: 'COTS'},
      { label: 'Custom', value: 'Custom'}
    ];
  }

  else if(this.complexityAddValue  == "App Component"){
    this.allData=[
    { label: 'Frontend only', value: 'Frontend only'},
    { label: 'Backend only', value: 'Backend only'},
    { label: 'Client server', value: 'Client server'}
  ];
  }

  else if(this.complexityAddValue  == "LOC"){
    this.allData=[
    { label: 'Less than 50K', value: 'Less than 50K'},
    { label: 'Between 50K to 500K', value: 'Between 50K to 500K'},
    { label: 'Between 500K to 1000K', value: 'Between 500K to 1000K'}
  ];
  }

   else if(this.complexityAddValue  == "Business Criticality"){
    this.allData=[
    { label: 'Low', value: 'Low'},
    { label: 'Medium', value: 'Medium'},
    { label: 'High', value: 'High'}
  ];
  }

 else if(this.complexityAddValue  == "Prod Servers"){
    this.allData=[
    { label: 'Less than 6', value: 'Less than 6'},
    { label: 'Between 7 to 20', value: 'Between 7 to 20'},
    { label: 'More than 20', value: 'More than 20'}
  ];
  }

 else if(this.complexityAddValue  == "Database Size"){
    this.allData=[
    { label: 'Less than 100GB', value: 'Less than 100GB'},
    { label: 'Between 100 to 500GB', value: 'Between 100 to 500GB'},
    { label: 'Between 500 to 2TB', value: 'Between 500 to 2TB'}
  ];
  }

  else if(this.complexityAddValue == "Database"){
    this.allData=[
    { label: 'DB2', value: 'DB2'},
    { label: 'MSSQL', value: 'MSSQL'},
    { label: 'Between 500 to 2TB', value: 'Between 500 to 2TB'},
    { label: 'MSSQL', value: 'MSSQL'},
    { label: 'MongoDB', value: 'MongoDB'},
    { label: 'MYSQL', value: 'MYSQL'},
    { label: 'Oracle', value: 'Oracle'},
    { label: 'Postgre', value: 'Postgre'},
    { label: 'Sybase', value: 'Sybase'},

  ];
  }

  else if(this.complexityAddValue  == "DatabaseMigrationType"){
    this.allData=[
    { label: 'IaaS', value: 'IaaS'},
    { label: 'PaaS', value: 'PaaS'}
  ];
  }

  else if(this.complexityAddValue  == "Contigency"){
    this.allData=[
    { label: 'Low-5%', value: 'Low-5%'},
    { label: 'Medium-10%', value: 'Medium-10%'},
    { label: 'High-20%', value: 'High-20%'}
  ];
  }

  else if(this.complexityAddValue  == "T Shirt Size"){
    this.allData=[
    { label: 'XS', value: 'XS'},
    { label: 'S', value: 'S'},
    { label: 'M', value: 'M'},
    { label: 'L', value: 'L'},
    { label: 'XL', value: 'XL'}
  ];
  }

 else if(this.complexityAddValue  == "Migration Type"){
    this.allData=[
    { label: 'Rehost', value: 'Rehost'},
    { label: 'Redeploy', value: 'Redeploy'},
    { label: 'Replatform', value: 'Replatform'}
  ];
  }
   else {
     this.complexityAddValue = null;
   }
  }
}
