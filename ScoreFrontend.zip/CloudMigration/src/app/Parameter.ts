export interface Parameter{
    parameterId:number;
    category:string;
    interfaces:string;
    LOC:string;
    db:string;
    dbObject:string;
    businessCriticality:string;
    appComponent:string;
    complianceNeed:string;
    specialhardwareNeed:string;
    tShirtSize: string;
    applyType:string;
}