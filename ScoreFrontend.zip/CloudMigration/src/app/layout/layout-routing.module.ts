import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {path:'',component:LayoutComponent,
    children: [
        {path:'', redirectTo:'score', pathMatch: 'prefix'},
        {path: 'score',
            loadChildren: () => import('../score/score.module').then(m=>m.ScoreModule)  
        },
        {
            path:'layout/score', redirectTo: 'score'
        },

        //{path:'/parameter', redirectTo:'parameter', pathMatch: 'prefix'},
        {path: 'parameter',
            loadChildren: () => import('../parameter/parameter.module').then(m=>m.ParameterModule)  
        },
        {
            path:'layout/parameter', redirectTo: 'parameter'
        }
    ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule { }
