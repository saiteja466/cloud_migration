
import { NgModule } from '@angular/core';
import { LayoutComponent } from './layout.component';
import { CommonModule } from '@angular/common';
import { LayoutRoutingModule } from './layout-routing.module';
import { HeaderComponent } from './components/header/header.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import {TooltipModule} from 'primeng/tooltip';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';



@NgModule({

  imports: [
    CommonModule,
    LayoutRoutingModule,
    TooltipModule,
    MessagesModule,
    MessageModule,
    NgbDropdownModule
    
  ],
  declarations:[LayoutComponent, HeaderComponent, SidebarComponent]
})
export class LayoutModule { }
