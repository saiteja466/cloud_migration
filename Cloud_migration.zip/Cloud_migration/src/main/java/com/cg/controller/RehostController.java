package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Rehost_Estimation;
import com.cg.service.RehostService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class RehostController {
	
	@Autowired
	RehostService service;
	
	@GetMapping(value="/getRehostEstimationById/{RehostId}")
	public ResponseEntity<Rehost_Estimation>  getRehostEstimationById(@PathVariable Integer RehostId) {
		Rehost_Estimation estimation = service.getRehostEstimationById(RehostId);
		return new ResponseEntity<Rehost_Estimation>(estimation, HttpStatus.OK);

	}
	
	
	@PostMapping(value="/addRehostEstimation")
	public String addRehostEstimation(@RequestBody Rehost_Estimation estimation) {
		boolean status = service.addRehostEstimation(estimation);
		if(status == true)
		{
			return ("Sucessfully Added");
		}
		return ("Failed to Add");
	}
	
	@PostMapping(value="/updateRehostEstimation")
	public ResponseEntity<String> updateReplatformEstimation(@RequestBody Rehost_Estimation estimation)
	{
		boolean status = service.updateRehostEstimation(estimation);
		if(status == true)
		{
			return new ResponseEntity<String>("Sucessfully Updated",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Failed to Update",HttpStatus.BAD_REQUEST);
	}
	
	@DeleteMapping(value="/deleteRehostEstimation/{RehostId}")
	public boolean deleteRehostEstimation(@PathVariable Integer RehostId)
	{
		boolean status = service.deleteRehostEstimation(RehostId);
		if(status == true)
		{
			return true;
		}
		return false;
	}
	
	@GetMapping(value="/getAllRehostEstimation")
	public ResponseEntity<List<Rehost_Estimation>> getAllRehostEstimation()
	{
		List<Rehost_Estimation> list = service.getAllRehostEstimation();
		return new ResponseEntity<List<Rehost_Estimation>>(list, HttpStatus.OK);
	}
	 
	

}
