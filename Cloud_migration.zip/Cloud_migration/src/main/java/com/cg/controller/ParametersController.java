package com.cg.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Parameters;
import com.cg.exceptions.ParameterIdNotFoundException;
import com.cg.exceptions.ParameterNotFoundException;
import com.cg.service.ParametersService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ParametersController {
	
	@Autowired
	private ParametersService parameterService;
	
	@GetMapping(value ="/getById/{parameterId}")
	public Parameters getParametersById(@PathVariable("parameterId") Integer parameterId) {
		
		return parameterService.getParameters(parameterId);
	}
	
	@GetMapping(value ="/getByCategory/{category}" )
	public List<Parameters> getParameterByTshirtSize(@PathVariable("category")String category) {
		return parameterService.getParameterByTshirtSize(category);
	}
	
	@PostMapping(value = "/addParameter")
	public String addParameters(@RequestBody Parameters parameter) {
		parameterService.addParameters(parameter);
		return "Parameter added Sucessfully";
	}
	
	@PutMapping(value = "/editParameter")
	public String updateParameter(@RequestBody Parameters parameter) {
		parameterService.updateParameter(parameter);
		return "Parameter updated sucessfully";
	}
	
	@DeleteMapping(value = "/deleteParameter/{parameterId}")
	public boolean deleteParameter(@PathVariable("parameterId") Integer parameterId) throws ParameterIdNotFoundException {
		
		parameterService.deleteParameter(parameterId);
		return true;
	}
	
	@GetMapping(value ="/getAllParameters" )
	public List<Parameters> getAllParameters() throws ParameterNotFoundException {
		
		return parameterService.getAllParameters();
	}

}