package com.cg.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entity.Redeploy_Estimation;
import com.cg.exceptions.RedeployEstimationException;
import com.cg.service.RedeployService;


@RestController
@CrossOrigin(origins="http://localhost:4200")
public class RedeployController {
	
	@Autowired
	RedeployService service;
	
	
	@GetMapping(value="/getRedeployEstimationById/{redeployId}") 
	public Redeploy_Estimation  getRedeployEstimationById(@PathVariable Integer redeployId) throws RedeployEstimationException {
		Redeploy_Estimation estimation = service.getRedeployEstimationById(redeployId);
		return estimation;

	}

	
	@PostMapping(value="/addRedeployEstimation")
	public String addRedeployEstimation(@RequestBody Redeploy_Estimation estimation) {
		boolean status = service.addRedeployEstimation(estimation);
		if(status == true)
		{
			return "Sucessfully Added";
		}
		return "Failed to Add";
	}
	
	@PostMapping(value="/updateRedeployEstimation")
	public String updateRedeployEstimation(@RequestBody Redeploy_Estimation estimation)
	{
		boolean status = service.updateRedeployEstimation(estimation);
		if(status == true)
		{
			return "Sucessfully Updated";
		}
		return "Failed to Update";
	}
	
	@DeleteMapping(value="/deleteRedeployEstimation/{RedeployId}")
	public boolean deleteRedeployEstimation(@PathVariable Integer RedeployId)
	{
		boolean status = service.deleteRedeployEstimation(RedeployId);
		if(status == true)
		{
			return true;
		}
		return false;
	}
	
	@GetMapping(value="/getAllRedeployEstimation")
	public List<Redeploy_Estimation> getAllRedeployEstimation()
	{
		List<Redeploy_Estimation> list = service.getAllRedeployEstimation();
		return list;
	}
	 
	
	
}