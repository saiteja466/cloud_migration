package com.cg.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Score;
import com.cg.service.ScoreService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ScoreController {

	@Autowired
	private ScoreService scoreService;

	@GetMapping(value = "/getScore/{scoreId}")
	public Score getScoreByScoreId(Integer scoreId) {

		return scoreService.getScoreByScoreId(scoreId);
	}

	@GetMapping(value = "getScoreByApplicationComplexity/{applicationComplexity}")
	public List<Score> getScoreByApplicationComplexity(
			@PathVariable("applicationComplexity") String applicationComplexity) {

		return scoreService.getScoreByApplicationComplexity(applicationComplexity);
	}

	@GetMapping(value = "getScoreByApplicationData/{applicationData}")
	public Score getScoreByApplicationData(@PathVariable("applicationData") String applicationData) {

		return scoreService.getScoreByApplicationData(applicationData);
	}

	@PostMapping(value = "/addScore")
	public String addScore(@RequestBody Score score) {

		scoreService.addScore(score);
		return "Score Sucessfully Added";
	}

	@PutMapping(value = "/editScore")
	public String editScore(@RequestBody Score score) {
		scoreService.editScore(score);
		return "Score Sucessfully Updated";
	}

	@GetMapping(value = "/getAllScore")
	public List<Score> getAllScores() {

		return scoreService.getAllScores();
	}

	@DeleteMapping(value = "/deleteScoreById/{scoreId}")
	public String deleteScoreById(@PathVariable("scoreId")Integer scoreId) {

		scoreService.deleteScoreById(scoreId);
		return "Score Sucessfully Deleted";

	}
}
