package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Replatform_Estimation;
import com.cg.service.ReplatformService;


@CrossOrigin(origins="http://localhost:4200")
@RestController
public class ReplatformController {

	@Autowired
	ReplatformService service;
	
	@GetMapping(value="/getReplatformEstimationById/{replatformId}")
	public ResponseEntity<Replatform_Estimation>  getReplatformEstimationById(@PathVariable Integer replatformId) {
		Replatform_Estimation estimation = service.getReplatformEstimationById(replatformId);
		return new ResponseEntity<Replatform_Estimation>(estimation, HttpStatus.OK);
	}
	
	
	@PostMapping(value="/addReplatformEstimation")
	public ResponseEntity<String> addReplatformEstimation(@RequestBody Replatform_Estimation estimation) {
		boolean status = service.addplatformEstimation(estimation);
		if(status == true)
		{
			return new ResponseEntity<String>("Sucessfully Added",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Failed to Add",HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping(value="/updateReplatformEstimation")
	public ResponseEntity<String> updateReplatformEstimation(@RequestBody Replatform_Estimation estimation)
	{
		boolean status = service.updateReplatformEstimation(estimation);
		if(status == true)
		{
			return new ResponseEntity<String>("Sucessfully Updated",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Failed to Update",HttpStatus.BAD_REQUEST);
	}
	
	@DeleteMapping(value="/deleteReplatformEstimation/{replatformId}")
	public boolean deleteReplatformEstimation(@PathVariable Integer replatformId)
	{
		boolean status = service.deleteReplatformEstimation(replatformId);
		if(status == true)
		{
			return true;
		}
		return false;
	}
	
	@GetMapping(value="/getAllReplatformEstimation")
	public ResponseEntity<List<Replatform_Estimation>> getAllReplatformEstimation()
	{
		List<Replatform_Estimation> list = service.getAllReplatformEstimation();
		return new ResponseEntity<List<Replatform_Estimation>>(list, HttpStatus.OK);
	}
}