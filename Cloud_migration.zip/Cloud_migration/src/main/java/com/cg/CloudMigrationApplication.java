package com.cg;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.dao.RehostDao;
import com.cg.dtos.EstimationRequestDto;
import com.cg.entity.Rehost_Estimation;

@SpringBootApplication
public class CloudMigrationApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(CloudMigrationApplication.class, args);
	}
	
//	@Autowired
//	EstimationRequestDto estDto;
	
	@Autowired
	RehostDao dao;

	@Override
	public void run(String... args) throws Exception {
		
//		EstimationRequestDto dto =new EstimationRequestDto();
//		dto.setAppComponent(null);
//		dto.setAppCountCluster(0);
//		dto.setApplyType("cots");
//		dto.setAppName(null);
//		dto.setBusinessCriticality(null);
//		dto.setComplianceNeed(null);
//		dto.setContigency(null);
//		dto.setDatabaseMigration(null);
//		dto.setDatabaseSize(null);
//		dto.setDbClass(null);
//		dto.setHaLbNeed(null);
//		dto.setHardwareNeed(null);
//		dto.setMigrationPattern("rehost");
//		dto.setNoEnvironment(0);
//		dto.setNoInterfaces(null);
//		dto.setNoLoc(null);
//		dto.setNoProdServer(null);
//		dto.setOsClass(null);
//		dto.setTargetDbClass(null);
		
		List<Rehost_Estimation> r = dao.getReshostEstByCategory("Design");
		System.out.println("cat");
		System.out.println(r);
		
		System.out.println(dao.getRehostEstByCotsTshirtSize("s"));	
		
	}
	
}