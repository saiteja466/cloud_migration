package com.cg.dtos;

public class EstimationRequestDto {

	
	private int estimationId;

	private String appName;

	private int appCountCluster;

	private String migrationPattern;

	private String noProdServer;

	private String dbClass;

	private String osClass;

	private String applyType;

	private String noInterfaces;

	private String complianceNeed;

	private String hardwareNeed;
	
	private String haLbNeed;

	private String appComponent;

	private String noLoc;

	private String businessCriticality;

	private String databaseSize;

	private String databaseMigration;

	private String targetDbClass;

	private int noEnvironment;

	private String contigency;

	public int getEstimationId() {
		return estimationId;
	}

	public void setEstimationId(int estimationId) {
		this.estimationId = estimationId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public int getAppCountCluster() {
		return appCountCluster;
	}

	public void setAppCountCluster(int appCountCluster) {
		this.appCountCluster = appCountCluster;
	}

	public String getMigrationPattern() {
		return migrationPattern;
	}

	public void setMigrationPattern(String migrationPattern) {
		this.migrationPattern = migrationPattern;
	}

	public String getNoProdServer() {
		return noProdServer;
	}

	public void setNoProdServer(String noProdServer) {
		this.noProdServer = noProdServer;
	}

	public String getDbClass() {
		return dbClass;
	}

	public void setDbClass(String dbClass) {
		this.dbClass = dbClass;
	}

	public String getOsClass() {
		return osClass;
	}

	public void setOsClass(String osClass) {
		this.osClass = osClass;
	}

	public String getApplyType() {
		return applyType;
	}

	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}

	public String getNoInterfaces() {
		return noInterfaces;
	}

	public void setNoInterfaces(String noInterfaces) {
		this.noInterfaces = noInterfaces;
	}

	public String getComplianceNeed() {
		return complianceNeed;
	}

	public void setComplianceNeed(String complianceNeed) {
		this.complianceNeed = complianceNeed;
	}

	public String getHardwareNeed() {
		return hardwareNeed;
	}

	public void setHardwareNeed(String hardwareNeed) {
		this.hardwareNeed = hardwareNeed;
	}

	public String getHaLbNeed() {
		return haLbNeed;
	}

	public void setHaLbNeed(String haLbNeed) {
		this.haLbNeed = haLbNeed;
	}

	public String getAppComponent() {
		return appComponent;
	}

	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}

	public String getNoLoc() {
		return noLoc;
	}

	public void setNoLoc(String noLoc) {
		this.noLoc = noLoc;
	}

	public String getBusinessCriticality() {
		return businessCriticality;
	}

	public void setBusinessCriticality(String businessCriticality) {
		this.businessCriticality = businessCriticality;
	}

	public String getDatabaseSize() {
		return databaseSize;
	}

	public void setDatabaseSize(String databaseSize) {
		this.databaseSize = databaseSize;
	}

	public String getDatabaseMigration() {
		return databaseMigration;
	}

	public void setDatabaseMigration(String databaseMigration) {
		this.databaseMigration = databaseMigration;
	}

	public String getTargetDbClass() {
		return targetDbClass;
	}

	public void setTargetDbClass(String targetDbClass) {
		this.targetDbClass = targetDbClass;
	}

	public int getNoEnvironment() {
		return noEnvironment;
	}

	public void setNoEnvironment(int noEnvironment) {
		this.noEnvironment = noEnvironment;
	}

	public String getContigency() {
		return contigency;
	}

	public void setContigency(String contigency) {
		this.contigency = contigency;
	}
	
	

}
