package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ReplatformDao;
import com.cg.entity.Replatform_Estimation;
import com.cg.exceptions.ReplatformEstimationException;



@Service
public class ReplatformServiceImpl implements ReplatformService {
	
	@Autowired
	private ReplatformDao dao;

	@Override
	public Replatform_Estimation getReplatformEstimationById(Integer replatformId) throws ReplatformEstimationException{
		if(dao.getReplatformEstimationById(replatformId) == null)
		{
			throw new ReplatformEstimationException("no result found");
		}
		return dao.getReplatformEstimationById(replatformId);
	}

	@Override
	public boolean addplatformEstimation(Replatform_Estimation estimation) throws ReplatformEstimationException{
		boolean add = dao.addplatformEstimation(estimation);
		if(add == true)
		{
			return true;
		}
		throw new ReplatformEstimationException("Failed to add the estimation");
	}

	@Override
	public boolean updateReplatformEstimation(Replatform_Estimation estimation) throws ReplatformEstimationException{
		boolean update = dao.updateReplatformEstimation(estimation);
		if(update == true)
		{
			return true;
		}
		throw new ReplatformEstimationException("Failed to edit the estimation");
	}

	@Override
	public boolean deleteReplatformEstimation(Integer replatformId) throws ReplatformEstimationException{
		boolean delete = dao.deleteReplatformEstimation(replatformId);
		if(delete == true)
		{
			return true;
		}
		throw new ReplatformEstimationException("Failed to delete the estimation");
	}

	@Override
	public List<Replatform_Estimation> getAllReplatformEstimation() throws ReplatformEstimationException{
		List<Replatform_Estimation> estimation = dao.getAllReplatformEstimation();
		if(estimation.size() == 0)
		{
			throw new ReplatformEstimationException("Failed to get the  all estimations");
		}
		return dao.getAllReplatformEstimation();
	}

}
