package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.RehostDao;
import com.cg.entity.Rehost_Estimation;
import com.cg.exceptions.RehostEstimationException;


@Service
public class RehostServiceImpl implements RehostService {
	
	@Autowired
	private RehostDao dao;
	
	@Override
	public Rehost_Estimation getRehostEstimationById(Integer rehostId) throws RehostEstimationException{
		if(dao.getRehostEstimationById(rehostId)== null)
		{
			throw new RehostEstimationException("no result found");
		}
		else {
		return dao.getRehostEstimationById(rehostId);
		}
	 }

	@Override
	public boolean addRehostEstimation(Rehost_Estimation estimation) throws RehostEstimationException{
		boolean add =dao.addRehostEstimation(estimation);
		if(add == true)
		{
			return true;
		}
		else {
		throw new RehostEstimationException("Failed to add the estimation");
		}
	}

	@Override
	public boolean updateRehostEstimation(Rehost_Estimation estimation) throws RehostEstimationException{
		boolean update = dao.updateRehostEstimation(estimation);
		if(update == true)
		{
			return true;
		}
		else {
		throw new RehostEstimationException("Failed to edit the estimation");
		}
	}

	@Override
	public boolean deleteRehostEstimation(Integer rehostId) throws RehostEstimationException{
		boolean  delete = dao.deleteRehostEstimation(rehostId);
		if(delete != true)
		{
			throw new RehostEstimationException("Failed to remove the estimation");
		}
		return true;
	}

	@Override
	public List<Rehost_Estimation> getAllRehostEstimation() throws RehostEstimationException{
		List<Rehost_Estimation> estimation = dao.getAllRehostEstimation();
		if(estimation.size() == 0)
		{
			throw new RehostEstimationException("Failed to get all the estimations");
		}
		return dao.getAllRehostEstimation();
	}

	@Override
	public List<Rehost_Estimation> getReshostEstByCategory(String category) throws RehostEstimationException {
		List<Rehost_Estimation> estimation = dao.getReshostEstByCategory(category);
		if(estimation.size() == 0)
		{
			throw new RehostEstimationException("Failed to get all the estimations");
		}
		return estimation;
	}

	@Override
	public List<Rehost_Estimation> getRehostEstByCotsTshirtSize(String tshirt) throws RehostEstimationException {
		List<Rehost_Estimation> estimation = dao.getRehostEstByCotsTshirtSize(tshirt);
		if(estimation.size() == 0)
		{
			throw new RehostEstimationException("Failed to get all the estimations");
		}
		return estimation;
	}

	@Override
	public List<Rehost_Estimation> getRehostEstByCustomTshirtSize(String tshirt) throws RehostEstimationException {
		List<Rehost_Estimation> estimation = dao.getRehostEstByCustomTshirtSize(tshirt);
		if(estimation.size() == 0)
		{
			throw new RehostEstimationException("Failed to get all the estimations");
		}
		return estimation;
	}
}