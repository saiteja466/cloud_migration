package com.cg.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ScoreDao;
import com.cg.entity.Score;


@Service
public class ScoreServiceImpl implements ScoreService {
	
	@Autowired
	private ScoreDao dao;
	
	

	@Override
	public Score getScoreByScoreId(Integer scoreId) {
		
		return dao.getScoreByScoreId(scoreId);
	}

	@Override
	public List<Score> getScoreByApplicationComplexity(String applicationComplexity) {
		
		return dao.getScoreByApplicationComplexity(applicationComplexity);
	}

	@Override
	public Score getScoreByApplicationData(String applicationData) {
		
		return dao.getScoreByApplicationData(applicationData);
	}

	@Override
	public boolean addScore(Score score) {
		
		dao.addScore(score);
		return true;
	}

	@Override
	public boolean editScore(Score score) {
		dao.editScore(score);
		return true;
	}

	@Override
	public List<Score> getAllScores() {
		
		return dao.getAllScores();
	}

	@Override
	public boolean deleteScoreById(Integer scoreId) {
		dao.deleteScoreById(scoreId);
		return true;
	}

}
