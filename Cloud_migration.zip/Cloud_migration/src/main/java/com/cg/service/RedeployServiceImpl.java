package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.RedeployDao;
import com.cg.entity.Redeploy_Estimation;
import com.cg.exceptions.RedeployEstimationException;



@Service
public class RedeployServiceImpl implements RedeployService {
	
	@Autowired
	private RedeployDao dao;

	@Override
	public Redeploy_Estimation getRedeployEstimationById(Integer redeployId) throws RedeployEstimationException{
		
		if(dao.getRedeployEstimationById(redeployId) != null)
		{
			return dao.getRedeployEstimationById(redeployId);
			
		}
		throw new RedeployEstimationException("no result found");
	}

	@Override
	public boolean addRedeployEstimation(Redeploy_Estimation estimation) throws RedeployEstimationException{
		boolean add = dao.addRedeployEstimation(estimation);
		if(add == true)
		{
			return true;
		}
		throw new RedeployEstimationException("Failed to add the estimation");
	}

	@Override
	public boolean updateRedeployEstimation(Redeploy_Estimation estimation) throws RedeployEstimationException{
		boolean update = dao.updateRedeployEstimation(estimation);
		if(update==true)
		{
			return true;
		}
		throw new RedeployEstimationException("Failed to edit the estimation");
	}

	@Override
	public boolean deleteRedeployEstimation(Integer redeployId) throws RedeployEstimationException{
		
		boolean delete = dao.deleteRedeployEstimation(redeployId);
		if(delete!=true)
		{
			throw new RedeployEstimationException("Failed to remove the estimation");
		}
		return true;
	}

	@Override
	public List<Redeploy_Estimation> getAllRedeployEstimation() throws RedeployEstimationException{
		List<Redeploy_Estimation> estimation = dao.getAllRedeployEstimation();
		if(estimation.size() == 0)
		{
			throw new RedeployEstimationException("Failed to get the list of estimations");
		}
		return estimation;
	}
	
	
	
}