package com.cg.service;

import java.util.List;

import com.cg.entity.Score;

public interface ScoreService {
	
	public Score getScoreByScoreId(Integer scoreId);
	
	public List<Score> getScoreByApplicationComplexity(String applicationComplexity);
	
	public Score getScoreByApplicationData(String applicationData);
	
	public boolean addScore(Score score);
	
	public boolean editScore(Score score);
	
	public List<Score> getAllScores();
	
	public boolean deleteScoreById(Integer scoreId);

}
