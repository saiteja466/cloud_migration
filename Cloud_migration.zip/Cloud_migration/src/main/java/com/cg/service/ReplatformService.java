package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.entity.Replatform_Estimation;
import com.cg.exceptions.ReplatformEstimationException;



@Service
public interface ReplatformService {
	
public Replatform_Estimation getReplatformEstimationById(Integer replatformId) throws ReplatformEstimationException;	
	
	public boolean addplatformEstimation(Replatform_Estimation estimation) throws ReplatformEstimationException;
	
	public boolean updateReplatformEstimation(Replatform_Estimation estimation) throws ReplatformEstimationException;
	
	public boolean deleteReplatformEstimation(Integer replatformId) throws ReplatformEstimationException;
	
	public List<Replatform_Estimation> getAllReplatformEstimation() throws ReplatformEstimationException;


}
