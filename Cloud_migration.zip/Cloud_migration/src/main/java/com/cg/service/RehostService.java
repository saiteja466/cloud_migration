package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.entity.Rehost_Estimation;
import com.cg.exceptions.RehostEstimationException;;

@Service
public interface RehostService {
	
public Rehost_Estimation getRehostEstimationById(Integer rehostId) throws RehostEstimationException;	
	
	public boolean addRehostEstimation(Rehost_Estimation estimation) throws RehostEstimationException;
	
	public boolean updateRehostEstimation(Rehost_Estimation estimation) throws RehostEstimationException;
	
	public boolean deleteRehostEstimation(Integer rehostId) throws RehostEstimationException;
	
	public List<Rehost_Estimation> getAllRehostEstimation() throws RehostEstimationException;
	
	public List<Rehost_Estimation> getReshostEstByCategory(String category) throws RehostEstimationException;
	
	public List<Rehost_Estimation> getRehostEstByCotsTshirtSize(String tshirt) throws RehostEstimationException;
	
	public List<Rehost_Estimation> getRehostEstByCustomTshirtSize(String tshirt) throws RehostEstimationException;

}
