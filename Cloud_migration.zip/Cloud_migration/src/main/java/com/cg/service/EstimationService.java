package com.cg.service;

import java.util.List;

import com.cg.dtos.EstimationRequestDto;
import com.cg.entity.Estimation_Template;



public interface EstimationService {

public Estimation_Template getEstimations(Integer estimationId );
	
	public boolean addEstimation(EstimationRequestDto estimationDto);
	
	public boolean updateEstimation(Estimation_Template estimation);
	
	public boolean deleteEstimation(Integer estimationId);
	
	public List<Estimation_Template> getAllEstimation();
}
