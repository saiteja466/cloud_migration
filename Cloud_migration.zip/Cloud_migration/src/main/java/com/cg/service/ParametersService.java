package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.entity.Parameters;
import com.cg.exceptions.ParameterIdNotFoundException;
import com.cg.exceptions.ParameterNotFoundException;


@Service
public interface ParametersService {
	
public Parameters getParameters(Integer parameterId);
	
	public List<Parameters> getParameterByTshirtSize(String tShirtSize);
	
	public boolean addParameters(Parameters parameter);
	
	public boolean updateParameter(Parameters parameter);
	
	public boolean deleteParameter(Integer parameterId) throws ParameterIdNotFoundException;
	
	public List<Parameters> getAllParameters() throws ParameterNotFoundException;

}
