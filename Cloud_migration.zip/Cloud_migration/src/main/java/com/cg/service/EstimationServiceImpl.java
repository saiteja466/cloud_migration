package com.cg.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.EstimationDao;
import com.cg.dao.RedeployDao;
import com.cg.dao.RehostDao;
import com.cg.dao.ReplatformDao;
import com.cg.dao.ScoreDao;
import com.cg.dtos.EstimationRequestDto;
import com.cg.entity.Estimation_Template;
import com.cg.entity.Redeploy_Estimation;
import com.cg.entity.Rehost_Estimation;
import com.cg.entity.Replatform_Estimation;
import com.cg.entity.Score;


@Service
public class EstimationServiceImpl implements EstimationService{

	@Autowired
	private EstimationDao dao;
	
	@Autowired
	private ScoreDao scoreDao;
	
	@Autowired
	private RehostDao rehostDao;
	
	@Autowired
	private ReplatformDao replatformDao;
	
	@Autowired 
	private RedeployDao redeployDao;
	
	private Integer sum=0;
	
	
	
	@Override
	public Estimation_Template getEstimations(Integer estimationId) {
		
		return dao.getEstimations(estimationId);
	}

	@Override
	public boolean addEstimation(EstimationRequestDto estimationDto) {
		Estimation_Template estimationTemp = new Estimation_Template();
		if(dao.getEstimations(estimationDto.getEstimationId())== null) {
			estimationTemp.setAppName(Optional.ofNullable(estimationDto.getAppName()).orElse(""));
			estimationTemp.setAppCountCluster(estimationDto.getAppCountCluster());
			estimationTemp.setMigrationPattern(Optional.ofNullable(estimationDto.getMigrationPattern()).orElse(""));
			estimationTemp.setNoProdServer(Optional.ofNullable(estimationDto.getNoProdServer()).orElse(""));
			estimationTemp.setDbClass(Optional.ofNullable(estimationDto.getDbClass()).orElse(""));
			estimationTemp.setOsClass(Optional.ofNullable(estimationDto.getOsClass()).orElse(""));
			estimationTemp.setApplyType(Optional.ofNullable(estimationDto.getApplyType()).orElse(""));
			estimationTemp.setNoInterfaces(Optional.ofNullable(estimationDto.getNoInterfaces()).orElse(""));
			estimationTemp.setComplianceNeed(Optional.ofNullable(estimationDto.getComplianceNeed()).orElse(""));
			estimationTemp.setHardwareNeed(Optional.ofNullable(estimationDto.getHardwareNeed()).orElse(""));
			estimationTemp.setHaLbNeed(Optional.ofNullable(estimationDto.getHaLbNeed()).orElse(""));
			estimationTemp.setAppComponent(Optional.ofNullable(estimationDto.getAppComponent()).orElse(""));
			estimationTemp.setNoLoc(Optional.ofNullable(estimationDto.getNoLoc()).orElse(""));
			estimationTemp.setBusinessCriticality(Optional.ofNullable(estimationDto.getBusinessCriticality()).orElse(""));
			estimationTemp.setDatabaseSize(Optional.ofNullable(estimationDto.getDatabaseSize()).orElse(""));
			estimationTemp.setDatabaseMigration(Optional.ofNullable(estimationDto.getDatabaseMigration()).orElse(""));
			estimationTemp.setTargetDbClass(Optional.ofNullable(estimationDto.getTargetDbClass()).orElse(""));
			estimationTemp.setNoEnvironment(estimationDto.getNoEnvironment());
			estimationTemp.setContigency(Optional.ofNullable(estimationDto.getContigency()).orElse(""));
		
			if(estimationDto.getNoProdServer() != null) {
				String noOfprod = estimationDto.getNoProdServer();
				Score score = scoreDao.getScoreByApplicationData(noOfprod);
				if(noOfprod.equals(score.getApplicationData())) {
					estimationTemp.setFinalProdServer(score.getScore());
					sum += score.getScore();
				}
			}
			
			if(estimationDto.getDbClass() != null) {
				String dbClass = estimationDto.getDbClass();
				Score score = scoreDao.getScoreByApplicationData(dbClass);
				if(dbClass.equals(score.getApplicationData())) {
					estimationTemp.setFinalDbClass(score.getScore());
					sum += score.getScore();
				}
			}
			
			if(estimationDto.getApplyType() != null) {
				String applyType = estimationDto.getApplyType();
				Score score = scoreDao.getScoreByApplicationData(applyType);
				if(applyType.equals(score.getApplicationData())) {
					estimationTemp.setFinalApplyType(score.getScore());
					sum += score.getScore();
				}
			}
			
			if(estimationDto.getNoInterfaces() != null) {
				String data = estimationDto.getNoInterfaces();
				Score score = scoreDao.getScoreByApplicationData(data);
				if(data.equals(score.getApplicationData())) {
					estimationTemp.setFinalIntegration(score.getScore());
					sum += score.getScore();
				}
			}
			
			if(estimationDto.getComplianceNeed() !=null ) {
				if(estimationDto.getComplianceNeed()== "Yes") {
					estimationTemp.setFinalComplianceNeed(10);
					sum += 10;
				} else if(estimationDto.getComplianceNeed()=="No") {
					estimationTemp.setFinalComplianceNeed(0);
					sum += 0;
					
				}
			}
			
			if(estimationDto.getHardwareNeed() !=null ) {
				if(estimationDto.getHardwareNeed() == "Yes") {
					estimationTemp.setFinalHardwareNeed(10);
					sum += 10;
				} else if(estimationDto.getHardwareNeed() =="No") {
					estimationTemp.setFinalHardwareNeed(0);
					sum += 0;
				}
			}
			
			if(estimationDto.getHaLbNeed() != null) {
				String data = estimationDto.getHaLbNeed();
				Score score = scoreDao.getScoreByApplicationData(data);
				if(data.equals(score.getApplicationData())){
					estimationTemp.setFinalHalbNeed(score.getScore());
					sum += score.getScore();
				}
			}
			
			if(estimationDto.getAppComponent() != null) {
				String data = estimationDto.getAppComponent();
				Score score =scoreDao.getScoreByApplicationData(data);
				if(data.equals(score.getApplicationData())) {
					estimationTemp.setFinalAppComponent(score.getScore());
					sum += score.getScore();
				}
			}
			
			if(estimationDto.getNoLoc() != null) {
				String data = estimationDto.getNoLoc();
				Score score =scoreDao.getScoreByApplicationData(data);
				if(data.equals(score.getApplicationData())) {
					estimationTemp.setFinalLoc(score.getScore());
					sum += score.getScore();
				}
			}
			
			if(estimationDto.getBusinessCriticality() != null) {
				String data = estimationDto.getBusinessCriticality();
				Score score =scoreDao.getScoreByApplicationData(data);
				if(data.equals(score.getApplicationData())) {
					estimationTemp.setFinalBusinessCriticality(score.getScore());
					sum += score.getScore();
				}
			}
			
			if(estimationDto.getDatabaseSize() != null) {
				String data = estimationDto.getDatabaseSize();
				Score score =scoreDao.getScoreByApplicationData(data);
				if(data.equals(score.getApplicationData())) {
					estimationTemp.setFinalDatabaseSize(score.getScore());
					sum += score.getScore();
				}
			}
			
			estimationTemp.setAppScore(sum);
			if(sum <= scoreDao.getScoreByApplicationData("XS").getScore()) {
				estimationTemp.setApplicationTshirtSize("XS");
			} else if(sum <= scoreDao.getScoreByApplicationData("S").getScore()) {
				estimationTemp.setApplicationTshirtSize("S");
			} else if(sum <= scoreDao.getScoreByApplicationData("M").getScore()) {
				estimationTemp.setApplicationTshirtSize("M");
			} else if(sum <= scoreDao.getScoreByApplicationData("L").getScore()) {
				estimationTemp.setApplicationTshirtSize("L");
			} else if(sum <= scoreDao.getScoreByApplicationData("XL").getScore()) {
				estimationTemp.setApplicationTshirtSize("XL");
			}
			
			
			estimationTemp.setFinalNoEnvironments(estimationDto.getNoEnvironment());
			estimationTemp.setKey(estimationDto.getMigrationPattern()+"-"+estimationTemp.getApplicationTshirtSize()+"-"+
			estimationDto.getApplyType());
			
//			if(estimationDto.getMigrationPattern() == "rehost"){
//				List<Rehost_Estimation> est = rehostDao.getAllRehostEstimation();
//				for(int loop=0;loop<=est.size();loop++)
//				{
//					if(est.get(loop).getCategory() == "Discovery(PD)") {
//						if(estimationDto.getApplyType() == "cots") {
//							if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
//								estimationTemp.setDiscoveryEfforts(est.get(loop).getCots_value());
//							}
//						}
//						else if(estimationDto.getApplyType() == "custom") {
//							if(est.get(loop).getCustom_tshirt_size()==estimationTemp.getApplicationTshirtSize()) {
//								estimationTemp.setDiscoveryEfforts(est.get(loop).getCustom_value());
//							}
//						}
//					}
//				}
//			}
//			else if(estimationDto.getMigrationPattern() == "replatform") {
//				List<Replatform_Estimation> est=replatformDao.getAllReplatformEstimation();
//				for(int loop=0;loop<=est.size();loop++)
//				{
//					if(est.get(loop).getCategory() == "Discovery(PD)") {
//						if(estimationDto.getApplyType() == "cots") {
//							if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
//								estimationTemp.setDiscoveryEfforts(est.get(loop).getCots_value());
//							}
//						}
//						else if(estimationDto.getApplyType() == "custom") {
//							if(est.get(loop).getCustom_tshirt_size()==estimationTemp.getApplicationTshirtSize()) {
//								estimationTemp.setDiscoveryEfforts(est.get(loop).getCustom_value());
//							}
//						}
//					}
//				}
//			}
//			else if(estimationDto.getMigrationPattern() == "redeploy") {
//				List<Redeploy_Estimation> est=redeployDao.getAllRedeployEstimation();
//				for(int loop=0;loop<=est.size();loop++)
//				{
//					if(est.get(loop).getCategory() == "Discovery(PD)") {
//						if(estimationDto.getApplyType() == "cots") {
//							if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
//								estimationTemp.setDiscoveryEfforts(est.get(loop).getCots_value());
//							}
//						}
//						else if(estimationDto.getApplyType() == "custom") {
//							if(est.get(loop).getCustom_tshirt_size()==estimationTemp.getApplicationTshirtSize()) {
//								estimationTemp.setDiscoveryEfforts(est.get(loop).getCustom_value());
//							}
//						}
//					}
//				}
//			}
//			else {
//				
//			}
			
			if(estimationDto.getMigrationPattern() == "redeploy") {
				List<Redeploy_Estimation> est=redeployDao.getRedeployEstByCategory("Discovery(PD)");
				if(estimationDto.getApplyType() == "cots") {
					double sum=0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCots_value();
						}
					}
					estimationTemp.setDiscoveryEfforts(sum);
					estimationTemp.setDiscoveryFull(sum*estimationTemp.getAppCountCluster());
				}
				else {
					double sum=0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCustom_value();
						}
					}
					estimationTemp.setDiscoveryEfforts(sum);
					estimationTemp.setDiscoveryFull(sum*estimationTemp.getAppCountCluster());
				}
			}
			
			
			if(estimationDto.getMigrationPattern() == "rehost") {
				List<Rehost_Estimation> est=rehostDao.getReshostEstByCategory("Discovery(PD)");
				if(estimationDto.getApplyType() == "cots") {
					double sum=0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCots_value();
						}
					}
					estimationTemp.setDiscoveryEfforts(sum);
					estimationTemp.setDiscoveryFull(sum*estimationTemp.getAppCountCluster());
					
				}
				else {
					double sum=0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCustom_value();
						}
					}
					estimationTemp.setDiscoveryEfforts(sum);
					estimationTemp.setDiscoveryFull(sum*estimationTemp.getAppCountCluster());
				}
			}
			
			if(estimationDto.getMigrationPattern() == "replatform") {
				List<Replatform_Estimation> est=replatformDao.getReplatformEstByCategory("Discovery(PD)");
				if(estimationDto.getApplyType() == "COTS") {
					double sum=0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCots_value();
						}
					}
					estimationTemp.setDiscoveryEfforts(sum);
					estimationTemp.setDiscoveryFull(sum*estimationTemp.getAppCountCluster());
				}
				else {
					double sum=0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCustom_value();
						}
					}
					estimationTemp.setDiscoveryEfforts(sum);
					estimationTemp.setDiscoveryFull(sum*estimationTemp.getAppCountCluster());
				}
			}
			
			
			
			if(estimationDto.getMigrationPattern() == "redeploy") {
				List<Redeploy_Estimation> est = redeployDao.getRedeployEstByCategory("Design Efforts(PD)");
				if(estimationDto.getApplyType() == "cots") {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCots_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
					estimationTemp.setDesignFull(sum * estimationTemp.getAppCountCluster());
				}
				else {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCots_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
					estimationTemp.setDesignFull(sum * estimationTemp.getAppCountCluster());
				}	
			}
			else if(estimationDto.getMigrationPattern() == "rehost") {
				List<Rehost_Estimation> est = rehostDao.getReshostEstByCategory("Design Efforts(PD)");
				if(estimationDto.getApplyType() == "cots") {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCots_value();
						}
						estimationTemp.setDisignEffort(sum);
						estimationTemp.setDesignFull(sum * estimationTemp.getAppCountCluster());
					}
				}
				else {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCustom_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
					estimationTemp.setDesignFull(sum * estimationTemp.getAppCountCluster());
				}	
			}
			else if(estimationDto.getMigrationPattern() == "replatform") {
				List<Replatform_Estimation> est = replatformDao.getReplatformEstByCategory("Design Efforts(PD)");
				if(estimationDto.getApplyType() == "cots") {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+= est.get(loop).getCots_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
					estimationTemp.setDesignFull(sum * estimationTemp.getAppCountCluster());
				}
				else {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCustom_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
					estimationTemp.setDesignFull(sum * estimationTemp.getAppCountCluster());
				}	
			}
			
			
			
			if(estimationDto.getMigrationPattern() == "redeploy") {
				List<Redeploy_Estimation> est = redeployDao.getRedeployEstByCategory("Build + Testing(PD)");
				if(estimationDto.getApplyType() == "cots") {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCots_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
				}
				else {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCustom_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
				}	
			}
			
			
			else if(estimationDto.getMigrationPattern() == "rehost") {
				List<Rehost_Estimation> est = rehostDao.getReshostEstByCategory("Build + Testing(PD)");
				if(estimationDto.getApplyType() == "cots") {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCots_value();
						}
						estimationTemp.setDisignEffort(sum);
					}
				}
				else {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCustom_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
				}	
			}
			else if(estimationDto.getMigrationPattern() == "replatform") {
				List<Replatform_Estimation> est = replatformDao.getReplatformEstByCategory("Build + Testing(PD)");
				if(estimationDto.getApplyType() == "cots") {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCots_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+= est.get(loop).getCots_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
				}
				else {
					double sum =0;
					for(int loop=0;loop<=est.size();loop++) {
						if(est.get(loop).getCustom_tshirt_size() == estimationTemp.getApplicationTshirtSize()) {
							sum+=est.get(loop).getCustom_value();
						}
					}
					estimationTemp.setDisignEffort(sum);
				}
			}
			
		}
		return false;
	}
	
	

	@Override
	public boolean updateEstimation(Estimation_Template estimation) {
		
		return false;
	}

	@Override
	public boolean deleteEstimation(Integer estimationId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Estimation_Template> getAllEstimation() {
		// TODO Auto-generated method stub
		return null;
	}
	
}