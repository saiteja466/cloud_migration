package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ParameterDao;
import com.cg.entity.Parameters;
import com.cg.exceptions.ParameterIdNotFoundException;
import com.cg.exceptions.ParameterNotFoundException;

@Service
public class ParametersServiceImpl implements ParametersService {

	@Autowired
	private ParameterDao dao;

	@Override
	public Parameters getParameters(Integer parameterId) {
		Parameters parameter = dao.getParameters(parameterId);
		return parameter;
	}

	@Override
	public List<Parameters> getParameterByTshirtSize(String tShirtSize) {

		return dao.getParameterByTshirtSize(tShirtSize);
	}

	@Override
	public boolean addParameters(Parameters parameter) {
		dao.addParameters(parameter);
		return true;
	}

	@Override
	public boolean updateParameter(Parameters parameter) {
		dao.updateParameter(parameter);
		return true;
	}

	@Override
	public boolean deleteParameter(Integer parameterId) throws ParameterIdNotFoundException {
		
		boolean result = dao.deleteParameter(parameterId);
		if(result != true)
			throw new ParameterIdNotFoundException();
		return true;
	}

	@Override
	public List<Parameters> getAllParameters() throws ParameterNotFoundException {
		
		List<Parameters> parametersList = dao.getAllParameters();
		if(parametersList.isEmpty())
			throw new ParameterNotFoundException();
		return parametersList;
	}

}
