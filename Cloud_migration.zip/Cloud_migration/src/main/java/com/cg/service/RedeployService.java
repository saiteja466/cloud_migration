package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.entity.Redeploy_Estimation;
import com.cg.exceptions.RedeployEstimationException;


@Service
public interface RedeployService {
	
	public Redeploy_Estimation getRedeployEstimationById(Integer redeployId) throws RedeployEstimationException;	
	
	public boolean addRedeployEstimation(Redeploy_Estimation estimation) throws RedeployEstimationException;
	
	public boolean updateRedeployEstimation(Redeploy_Estimation estimation) throws RedeployEstimationException;
	
	public boolean deleteRedeployEstimation(Integer redeployId) throws RedeployEstimationException;
	
	public List<Redeploy_Estimation> getAllRedeployEstimation() throws RedeployEstimationException;
}