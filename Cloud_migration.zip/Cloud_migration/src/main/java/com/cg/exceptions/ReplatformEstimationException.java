package com.cg.exceptions;

public class ReplatformEstimationException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public ReplatformEstimationException(String msg)
	{
		super(msg);
	}	

}
