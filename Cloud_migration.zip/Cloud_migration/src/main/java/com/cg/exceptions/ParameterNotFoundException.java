package com.cg.exceptions;

public class ParameterNotFoundException extends Exception {

	public ParameterNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ParameterNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
	
}
