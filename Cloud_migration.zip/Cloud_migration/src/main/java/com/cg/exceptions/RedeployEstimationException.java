package com.cg.exceptions;

public class RedeployEstimationException extends RuntimeException{
	
	
	private static final long serialVersionUID = 1L;

	public RedeployEstimationException(String msg)
	{
		super(msg);
	}	

}
