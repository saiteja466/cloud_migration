package com.cg.exceptions;

public class RehostEstimationException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public RehostEstimationException(String msg)
	{
		super(msg);
	}	
}
