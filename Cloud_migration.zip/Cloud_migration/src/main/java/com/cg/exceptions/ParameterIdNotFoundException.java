package com.cg.exceptions;

public class ParameterIdNotFoundException extends Exception {

	public ParameterIdNotFoundException() {
		super();

	}

	
	public ParameterIdNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}

	public ParameterIdNotFoundException(String arg0) {
		super(arg0);

	}

	
	
	

}
