package com.cg.entity;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name ="score")
public class Score {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name =" score_id")
	private Integer scoreId;
	
	@Column(name ="application_complexity")
	private String applicationComplexity;
	
	@Column(name ="application_data")
	private String applicationData;
	
	@Column(name ="score")
	private Integer score;
	
	
	public Score() {
		super();
		
	}


	public Score(Integer scoreId, String applicationComplexity, String applicationData, Integer score) {
		super();
		this.scoreId = scoreId;
		this.applicationComplexity = applicationComplexity;
		this.applicationData = applicationData;
		this.score = score;
	}


	public Integer getScoreId() {
		return scoreId;
	}


	public void setScoreId(Integer scoreId) {
		this.scoreId = scoreId;
	}


	public String getApplicationComplexity() {
		return applicationComplexity;
	}


	public void setApplicationComplexity(String applicationComplexity) {
		this.applicationComplexity = applicationComplexity;
	}


	public String getApplicationData() {
		return applicationData;
	}


	public void setApplicationData(String applicationData) {
		this.applicationData = applicationData;
	}


	public Integer getScore() {
		return score;
	}


	public void setScore(Integer score) {
		this.score = score;
	}


	@Override
	public String toString() {
		return "Score [scoreId=" + scoreId + ", applicationComplexity=" + applicationComplexity + ", applicationData="
				+ applicationData + ", score=" + score + "]";
	}
	
	
	

}
