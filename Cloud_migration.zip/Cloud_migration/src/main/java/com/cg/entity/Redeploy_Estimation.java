package com.cg.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;


@Entity
@DynamicInsert
@DynamicUpdate
@Table(name="redeploy_estimation")
public class Redeploy_Estimation {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "redeploy_seq")
	@SequenceGenerator(sequenceName = "redeploy_seq", initialValue = 100, allocationSize = 1, name = "redeploy_seq")
	@Column(name="redeploy_id")
	private int redeploy_id;
	
	@Column(name="category")
	private String category;
	
	@Column(name="activities")
	private String activities;
	
	@Column(name="cots_activities")
	private String cots_activities;
	
	@Column(name="cots_tshirt_size")
	private String cots_tshirt_size;
	
	@Column(name="cots_value")
	private double cots_value;
	
	@Column(name="custom_activities")
	private String custom_activities;
	
	@Column(name="custom_tshirt_size")
	private String custom_tshirt_size;
	
	@Column(name="custom_value")
	private double custom_value;

	public int getRedeploy_id() {
		return redeploy_id;
	}

	public void setRedeploy_id(int redeploy_id) {
		this.redeploy_id = redeploy_id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCots_activities() {
		return cots_activities;
	}

	public void setCots_activities(String cots_activities) {
		this.cots_activities = cots_activities;
	}

	public String getCots_tshirt_size() {
		return cots_tshirt_size;
	}

	public void setCots_tshirt_size(String cots_tshirt_size) {
		this.cots_tshirt_size = cots_tshirt_size;
	}

	public double getCots_value() {
		return cots_value;
	}

	public void setCots_value(double cots_value) {
		this.cots_value = cots_value;
	}

	public String getCustom_activities() {
		return custom_activities;
	}

	public void setCustom_activities(String custom_activities) {
		this.custom_activities = custom_activities;
	}

	public String getCustom_tshirt_size() {
		return custom_tshirt_size;
	}

	public void setCustom_tshirt_size(String custom_tshirt_size) {
		this.custom_tshirt_size = custom_tshirt_size;
	}

	public double getCustom_value() {
		return custom_value;
	}

	public void setCustom_value(double custom_value) {
		this.custom_value = custom_value;
	}

	public String getActivities() {
		return activities;
	}

	public void setActivities(String activities) {
		this.activities = activities;
	}

	
	@Override
	public String toString() {
		return "Redeploy_Estimation [redeploy_id=" + redeploy_id + ", category=" + category + ", activities="
				+ activities + ", cots_activities=" + cots_activities + ", cots_tshirt_size=" + cots_tshirt_size
				+ ", cots_value=" + cots_value + ", custom_activities=" + custom_activities + ", custom_tshirt_size="
				+ custom_tshirt_size + ", custom_value=" + custom_value + "]";
	}

	public Redeploy_Estimation(int redeploy_id, String category, String activities, String cots_activities,
			String cots_tshirt_size, double cots_value, String custom_activities, String custom_tshirt_size,
			double custom_value) {
		super();
		this.redeploy_id = redeploy_id;
		this.category = category;
		this.activities = activities;
		this.cots_activities = cots_activities;
		this.cots_tshirt_size = cots_tshirt_size;
		this.cots_value = cots_value;
		this.custom_activities = custom_activities;
		this.custom_tshirt_size = custom_tshirt_size;
		this.custom_value = custom_value;
	}

	public Redeploy_Estimation() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}