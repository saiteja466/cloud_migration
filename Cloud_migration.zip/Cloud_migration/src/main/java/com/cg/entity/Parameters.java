package com.cg.entity;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;


@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "parameters")
public class Parameters {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "parameter_id")
	private Integer parameterId;
	
	@Column(name = "category")
	private String category;
	
	@Column(name = "parameters")
	private String parameters;
	
	@Column(name = "tshirt_xs")
	private String tshirt_XS;
	
	@Column(name = "tshirt_s")
	private String tshirt_S;
	
	@Column(name = "tshirt_m")
	private String tshirt_M;
	
	@Column(name = "tshirt_l")
	private String tshirt_L;
	
	@Column(name = "tshirt_xl")
	private String tshirt_XL;

	public Parameters(Integer parameterId, String category, String parameters, String tshirt_XS, String tshirt_S,
			String tshirt_M, String tshirt_L, String tshirt_XL) {
		super();
		this.parameterId = parameterId;
		this.category = category;
		this.parameters = parameters;
		this.tshirt_XS = tshirt_XS;
		this.tshirt_S = tshirt_S;
		this.tshirt_M = tshirt_M;
		this.tshirt_L = tshirt_L;
		this.tshirt_XL = tshirt_XL;
	}

	public Parameters() {
		super();
	
	}

	public Integer getParameterId() {
		return parameterId;
	}

	public void setParameterId(Integer parameterId) {
		this.parameterId = parameterId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public String getTshirt_XS() {
		return tshirt_XS;
	}

	public void setTshirt_XS(String tshirt_XS) {
		this.tshirt_XS = tshirt_XS;
	}

	public String getTshirt_S() {
		return tshirt_S;
	}

	public void setTshirt_S(String tshirt_S) {
		this.tshirt_S = tshirt_S;
	}

	public String getTshirt_M() {
		return tshirt_M;
	}

	public void setTshirt_M(String tshirt_M) {
		this.tshirt_M = tshirt_M;
	}

	public String getTshirt_L() {
		return tshirt_L;
	}

	public void setTshirt_L(String tshirt_L) {
		this.tshirt_L = tshirt_L;
	}

	public String getTshirt_XL() {
		return tshirt_XL;
	}

	public void setTshirt_XL(String tshirt_XL) {
		this.tshirt_XL = tshirt_XL;
	}

	@Override
	public String toString() {
		return "Parameters [parameterId=" + parameterId + ", category=" + category + ", parameters=" + parameters
				+ ", tshirt_XS=" + tshirt_XS + ", tshirt_S=" + tshirt_S + ", tshirt_M=" + tshirt_M + ", tshirt_L="
				+ tshirt_L + ", tshirt_XL=" + tshirt_XL + "]";
	}
	
	
}
