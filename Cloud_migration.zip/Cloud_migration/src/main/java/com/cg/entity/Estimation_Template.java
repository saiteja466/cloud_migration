package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@DynamicInsert
@DynamicUpdate
@Entity
@Table(name = "estimation_template")
public class Estimation_Template {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "estimation_id")
	private int estimationId;

	@Column(name = "app_name")
	private String appName;

	@Column(name = "app_count_cluster")
	private int appCountCluster;

	@Column(name = "migration_pattern")
	private String migrationPattern;

	@Column(name = "no_prod_server")
	private String noProdServer;

	@Column(name = "db_class")
	private String dbClass;

	@Column(name = "os_class")
	private String osClass;

	@Column(name = "apply_type")
	private String applyType;

	@Column(name = "no_interfaces")
	private String noInterfaces;

	@Column(name = "compliance_need")
	private String complianceNeed;

	@Column(name = "hardware_need")
	private String hardwareNeed;

	@Column(name = "ha_lb_need")
	private String haLbNeed;

	@Column(name = "app_component")
	private String appComponent;

	@Column(name = "no_loc")
	private String noLoc;

	@Column(name = "business_criticality")
	private String businessCriticality;

	@Column(name = "database_size")
	private String databaseSize;

	@Column(name = "database_migration")
	private String databaseMigration;

	@Column(name = "target_db_class")
	private String targetDbClass;

	@Column(name = "no_environment")
	private int noEnvironment;

	@Column(name = "contigency")
	private String contigency;

	@Column(name = "final_prod_server")
	private int finalProdServer;

	@Column(name = "final_server_class")
	private int finalServerClass;

	@Column(name = "final_db_class")
	private int finalDbClass;

	@Column(name = "final_apply_type")
	private int finalApplyType;

	@Column(name = "final_integration")
	private int finalIntegration;

	@Column(name = "final_compliance_need")
	private int finalComplianceNeed;

	@Column(name = "final_hardware_need")
	private int finalHardwareNeed;

	@Column(name = "final_halb_need")
	private int finalHalbNeed;

	@Column(name = "final_app_component")
	private int finalAppComponent;

	@Column(name = "final_loc")
	private int finalLoc;

	@Column(name = "final_business_criticality")
	private int finalBusinessCriticality;

	@Column(name = "final_database_size")
	private int finalDatabaseSize;

	@Column(name = "final_database_migration")
	private int finalDatabaseMigration;

	@Column(name = "app_score")
	private int appScore;

	@Column(name = "application_tshirt_size")
	private String applicationTshirtSize;

	@Column(name = "final_no_environments")
	private int finalNoEnvironments;

	@Column(name = "key")
	private String key;

	@Column(name = "discovery_efforts")
	private Double discoveryEfforts;

	@Column(name = "discovery_full")
	private Double discoveryFull;

	@Column(name = "disign_effort")
	private Double disignEffort;

	@Column(name = "design_full")
	private Double designFull;

	@Column(name = "build_testing_efforts")
	private Double buildTestingEfforts;

	@Column(name = "factor_setting_env")
	private Double factorSettingEnv;

	@Column(name = "effort_inc_multiple_env")
	private Double effortIncMultipleEnv;

	@Column(name = "performance_testing")
	private Double performanceTesting;

	@Column(name = "security_testing")
	private Double securityTesting;

	@Column(name = "overall_efforts")
	private Double overallEfforts;

	@Column(name = "mgmt_efforts")
	private Double mgmtEfforts;

	@Column(name = "mgmt_full")
	private Double mgmtFull;

	@Column(name = "hypercare_efforts")
	private Double hypercareEfforts;

	@Column(name = "hypercare_full")
	private Double hypercareFull;

	@Column(name = "final_contigency")
	private int finalContigency;

	@Column(name = "final_overall_efforts")
	private Double finalOverallEfforts;

	@Column(name = "efforts_from_contigency")
	private Double effortsFromContigency;
	

	public Estimation_Template() {
		super();
		
	}

	public Estimation_Template(int estimationId, String appName, int appCountCluster, String migrationPattern,
			String noProdServer, String dbClass, String osClass, String applyType, String noInterfaces,
			String complianceNeed, String hardwareNeed, String haLbNeed, String appComponent, String noLoc,
			String businessCriticality, String databaseSize, String databaseMigration, String targetDbClass,
			int noEnvironment, String contigency, int finalProdServer, int finalServerClass, int finalDbClass,
			int finalApplyType, int finalIntegration, int finalComplianceNeed, int finalHardwareNeed, int finalHalbNeed,
			int finalAppComponent, int finalLoc, int finalBusinessCriticality, int finalDatabaseSize,
			int finalDatabaseMigration, int appScore, String applicationTshirtSize, int finalNoEnvironments, String key,
			Double discoveryEfforts, Double discoveryFull, Double disignEffort, Double designFull,
			Double buildTestingEfforts, Double factorSettingEnv, Double effortIncMultipleEnv, Double performanceTesting,
			Double securityTesting, Double overallEfforts, Double mgmtEfforts, Double mgmtFull, Double hypercareEfforts,
			Double hypercareFull, int finalContigency, Double finalOverallEfforts, Double effortsFromContigency) {
		super();
		this.estimationId = estimationId;
		this.appName = appName;
		this.appCountCluster = appCountCluster;
		this.migrationPattern = migrationPattern;
		this.noProdServer = noProdServer;
		this.dbClass = dbClass;
		this.osClass = osClass;
		this.applyType = applyType;
		this.noInterfaces = noInterfaces;
		this.complianceNeed = complianceNeed;
		this.hardwareNeed = hardwareNeed;
		this.haLbNeed = haLbNeed;
		this.appComponent = appComponent;
		this.noLoc = noLoc;
		this.businessCriticality = businessCriticality;
		this.databaseSize = databaseSize;
		this.databaseMigration = databaseMigration;
		this.targetDbClass = targetDbClass;
		this.noEnvironment = noEnvironment;
		this.contigency = contigency;
		this.finalProdServer = finalProdServer;
		this.finalServerClass = finalServerClass;
		this.finalDbClass = finalDbClass;
		this.finalApplyType = finalApplyType;
		this.finalIntegration = finalIntegration;
		this.finalComplianceNeed = finalComplianceNeed;
		this.finalHardwareNeed = finalHardwareNeed;
		this.finalHalbNeed = finalHalbNeed;
		this.finalAppComponent = finalAppComponent;
		this.finalLoc = finalLoc;
		this.finalBusinessCriticality = finalBusinessCriticality;
		this.finalDatabaseSize = finalDatabaseSize;
		this.finalDatabaseMigration = finalDatabaseMigration;
		this.appScore = appScore;
		this.applicationTshirtSize = applicationTshirtSize;
		this.finalNoEnvironments = finalNoEnvironments;
		this.key = key;
		this.discoveryEfforts = discoveryEfforts;
		this.discoveryFull = discoveryFull;
		this.disignEffort = disignEffort;
		this.designFull = designFull;
		this.buildTestingEfforts = buildTestingEfforts;
		this.factorSettingEnv = factorSettingEnv;
		this.effortIncMultipleEnv = effortIncMultipleEnv;
		this.performanceTesting = performanceTesting;
		this.securityTesting = securityTesting;
		this.overallEfforts = overallEfforts;
		this.mgmtEfforts = mgmtEfforts;
		this.mgmtFull = mgmtFull;
		this.hypercareEfforts = hypercareEfforts;
		this.hypercareFull = hypercareFull;
		this.finalContigency = finalContigency;
		this.finalOverallEfforts = finalOverallEfforts;
		this.effortsFromContigency = effortsFromContigency;
		
	}

	public int getEstimationId() {
		return estimationId;
	}

	public void setEstimationId(int estimationId) {
		this.estimationId = estimationId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public int getAppCountCluster() {
		return appCountCluster;
	}

	public void setAppCountCluster(int appCountCluster) {
		this.appCountCluster = appCountCluster;
	}

	public String getMigrationPattern() {
		return migrationPattern;
	}

	public void setMigrationPattern(String migrationPattern) {
		this.migrationPattern = migrationPattern;
	}

	public String getNoProdServer() {
		return noProdServer;
	}

	public void setNoProdServer(String noProdServer) {
		this.noProdServer = noProdServer;
	}

	public String getDbClass() {
		return dbClass;
	}

	public void setDbClass(String dbClass) {
		this.dbClass = dbClass;
	}

	public String getOsClass() {
		return osClass;
	}

	public void setOsClass(String osClass) {
		this.osClass = osClass;
	}

	public String getApplyType() {
		return applyType;
	}

	public void setApplyType(String applyType) {
		this.applyType = applyType;
	}

	public String getNoInterfaces() {
		return noInterfaces;
	}

	public void setNoInterfaces(String noInterfaces) {
		this.noInterfaces = noInterfaces;
	}

	public String getComplianceNeed() {
		return complianceNeed;
	}

	public void setComplianceNeed(String complianceNeed) {
		this.complianceNeed = complianceNeed;
	}

	public String getHardwareNeed() {
		return hardwareNeed;
	}

	public void setHardwareNeed(String hardwareNeed) {
		this.hardwareNeed = hardwareNeed;
	}

	public String getHaLbNeed() {
		return haLbNeed;
	}

	public void setHaLbNeed(String haLbNeed) {
		this.haLbNeed = haLbNeed;
	}

	public String getAppComponent() {
		return appComponent;
	}

	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}

	public String getNoLoc() {
		return noLoc;
	}

	public void setNoLoc(String noLoc) {
		this.noLoc = noLoc;
	}

	public String getBusinessCriticality() {
		return businessCriticality;
	}

	public void setBusinessCriticality(String businessCriticality) {
		this.businessCriticality = businessCriticality;
	}

	public String getDatabaseSize() {
		return databaseSize;
	}

	public void setDatabaseSize(String databaseSize) {
		this.databaseSize = databaseSize;
	}

	public String getDatabaseMigration() {
		return databaseMigration;
	}

	public void setDatabaseMigration(String databaseMigration) {
		this.databaseMigration = databaseMigration;
	}

	public String getTargetDbClass() {
		return targetDbClass;
	}

	public void setTargetDbClass(String targetDbClass) {
		this.targetDbClass = targetDbClass;
	}

	public int getNoEnvironment() {
		return noEnvironment;
	}

	public void setNoEnvironment(int noEnvironment) {
		this.noEnvironment = noEnvironment;
	}

	public String getContigency() {
		return contigency;
	}

	public void setContigency(String contigency) {
		this.contigency = contigency;
	}

	public int getFinalProdServer() {
		return finalProdServer;
	}

	public void setFinalProdServer(int finalProdServer) {
		this.finalProdServer = finalProdServer;
	}

	public int getFinalServerClass() {
		return finalServerClass;
	}

	public void setFinalServerClass(int finalServerClass) {
		this.finalServerClass = finalServerClass;
	}

	public int getFinalDbClass() {
		return finalDbClass;
	}

	public void setFinalDbClass(int finalDbClass) {
		this.finalDbClass = finalDbClass;
	}

	public int getFinalApplyType() {
		return finalApplyType;
	}

	public void setFinalApplyType(int finalApplyType) {
		this.finalApplyType = finalApplyType;
	}

	public int getFinalIntegration() {
		return finalIntegration;
	}

	public void setFinalIntegration(int finalIntegration) {
		this.finalIntegration = finalIntegration;
	}

	public int getFinalComplianceNeed() {
		return finalComplianceNeed;
	}

	public void setFinalComplianceNeed(int finalComplianceNeed) {
		this.finalComplianceNeed = finalComplianceNeed;
	}

	public int getFinalHardwareNeed() {
		return finalHardwareNeed;
	}

	public void setFinalHardwareNeed(int finalHardwareNeed) {
		this.finalHardwareNeed = finalHardwareNeed;
	}

	public int getFinalHalbNeed() {
		return finalHalbNeed;
	}

	public void setFinalHalbNeed(int finalHalbNeed) {
		this.finalHalbNeed = finalHalbNeed;
	}

	public int getFinalAppComponent() {
		return finalAppComponent;
	}

	public void setFinalAppComponent(int finalAppComponent) {
		this.finalAppComponent = finalAppComponent;
	}

	public int getFinalLoc() {
		return finalLoc;
	}

	public void setFinalLoc(int finalLoc) {
		this.finalLoc = finalLoc;
	}

	public int getFinalBusinessCriticality() {
		return finalBusinessCriticality;
	}

	public void setFinalBusinessCriticality(int finalBusinessCriticality) {
		this.finalBusinessCriticality = finalBusinessCriticality;
	}

	public int getFinalDatabaseSize() {
		return finalDatabaseSize;
	}

	public void setFinalDatabaseSize(int finalDatabaseSize) {
		this.finalDatabaseSize = finalDatabaseSize;
	}

	public int getFinalDatabaseMigration() {
		return finalDatabaseMigration;
	}

	public void setFinalDatabaseMigration(int finalDatabaseMigration) {
		this.finalDatabaseMigration = finalDatabaseMigration;
	}

	public int getAppScore() {
		return appScore;
	}

	public void setAppScore(int appScore) {
		this.appScore = appScore;
	}

	public String getApplicationTshirtSize() {
		return applicationTshirtSize;
	}

	public void setApplicationTshirtSize(String applicationTshirtSize) {
		this.applicationTshirtSize = applicationTshirtSize;
	}

	public int getFinalNoEnvironments() {
		return finalNoEnvironments;
	}

	public void setFinalNoEnvironments(int finalNoEnvironments) {
		this.finalNoEnvironments = finalNoEnvironments;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Double getDiscoveryEfforts() {
		return discoveryEfforts;
	}

	public void setDiscoveryEfforts(Double discoveryEfforts) {
		this.discoveryEfforts = discoveryEfforts;
	}

	public Double getDiscoveryFull() {
		return discoveryFull;
	}

	public void setDiscoveryFull(Double discoveryFull) {
		this.discoveryFull = discoveryFull;
	}

	public Double getDisignEffort() {
		return disignEffort;
	}

	public void setDisignEffort(Double disignEffort) {
		this.disignEffort = disignEffort;
	}

	public Double getDesignFull() {
		return designFull;
	}

	public void setDesignFull(Double designFull) {
		this.designFull = designFull;
	}

	public Double getBuildTestingEfforts() {
		return buildTestingEfforts;
	}

	public void setBuildTestingEfforts(Double buildTestingEfforts) {
		this.buildTestingEfforts = buildTestingEfforts;
	}

	public Double getFactorSettingEnv() {
		return factorSettingEnv;
	}

	public void setFactorSettingEnv(Double factorSettingEnv) {
		this.factorSettingEnv = factorSettingEnv;
	}

	public Double getEffortIncMultipleEnv() {
		return effortIncMultipleEnv;
	}

	public void setEffortIncMultipleEnv(Double effortIncMultipleEnv) {
		this.effortIncMultipleEnv = effortIncMultipleEnv;
	}

	public Double getPerformanceTesting() {
		return performanceTesting;
	}

	public void setPerformanceTesting(Double performanceTesting) {
		this.performanceTesting = performanceTesting;
	}

	public Double getSecurityTesting() {
		return securityTesting;
	}

	public void setSecurityTesting(Double securityTesting) {
		this.securityTesting = securityTesting;
	}

	public Double getOverallEfforts() {
		return overallEfforts;
	}

	public void setOverallEfforts(Double overallEfforts) {
		this.overallEfforts = overallEfforts;
	}

	public Double getMgmtEfforts() {
		return mgmtEfforts;
	}

	public void setMgmtEfforts(Double mgmtEfforts) {
		this.mgmtEfforts = mgmtEfforts;
	}

	public Double getMgmtFull() {
		return mgmtFull;
	}

	public void setMgmtFull(Double mgmtFull) {
		this.mgmtFull = mgmtFull;
	}

	public Double getHypercareEfforts() {
		return hypercareEfforts;
	}

	public void setHypercareEfforts(Double hypercareEfforts) {
		this.hypercareEfforts = hypercareEfforts;
	}

	public Double getHypercareFull() {
		return hypercareFull;
	}

	public void setHypercareFull(Double hypercareFull) {
		this.hypercareFull = hypercareFull;
	}

	public int getFinalContigency() {
		return finalContigency;
	}

	public void setFinalContigency(int finalContigency) {
		this.finalContigency = finalContigency;
	}

	public Double getFinalOverallEfforts() {
		return finalOverallEfforts;
	}

	public void setFinalOverallEfforts(Double finalOverallEfforts) {
		this.finalOverallEfforts = finalOverallEfforts;
	}

	public Double getEffortsFromContigency() {
		return effortsFromContigency;
	}

	public void setEffortsFromContigency(Double effortsFromContigency) {
		this.effortsFromContigency = effortsFromContigency;
	}

	

}