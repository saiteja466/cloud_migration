package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entity.Estimation_Template;
@Repository
@Transactional

public class EstimationDaoImpl implements EstimationDao{
	
	@PersistenceContext
	private EntityManager em;
	

	@Override
	public Estimation_Template getEstimations(Integer estimationId) {
		
		return em.find(Estimation_Template.class,estimationId);
	}


	@Override
	public boolean addEstimation(Estimation_Template estimation) {	
		em.persist(estimation);
		
		return true;
	}


	@Override
	public boolean updateEstimation(Estimation_Template estimation) {
		em.merge(estimation);
		return true;
	}


	@Override
	public boolean deleteEstimation(Integer estimationId) {
		Estimation_Template est = em.find(Estimation_Template.class, estimationId);
		em.remove(est);
		return true;
	}


	@Override
	public List<Estimation_Template> getAllEstimation() {
		String sqlQuery = "from Estimation_Template";
		TypedQuery<Estimation_Template> query = em.createQuery(sqlQuery, Estimation_Template.class);
		List<Estimation_Template> estLst = query.getResultList();
		return estLst;
	}

	

}
