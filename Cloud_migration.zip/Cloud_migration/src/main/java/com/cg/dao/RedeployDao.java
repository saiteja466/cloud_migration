package com.cg.dao;

import java.util.List;


import org.springframework.stereotype.Repository;

import com.cg.entity.Redeploy_Estimation;
import com.cg.entity.Replatform_Estimation;;

@Repository
public interface RedeployDao {

	public Redeploy_Estimation getRedeployEstimationById(Integer redeployId);	
	
	public boolean addRedeployEstimation(Redeploy_Estimation estimation);
	
	public boolean updateRedeployEstimation(Redeploy_Estimation estimation);
	
	public boolean deleteRedeployEstimation(Integer redeployId);
	
	public List<Redeploy_Estimation> getAllRedeployEstimation();
	
	public List<Redeploy_Estimation> getRedeployEstByCategory(String category);
	
	
	
	public List<Redeploy_Estimation> getRedeployEstByCotsTshirtSize(String tshirt);
	
	
	public List<Redeploy_Estimation> getRedeployEstByCustomTshirtSize(String tshirt);
}