package com.cg.dao;
import java.util.List;


import org.springframework.stereotype.Repository;

import com.cg.entity.Rehost_Estimation;
import com.cg.entity.Replatform_Estimation;



@Repository
public interface ReplatformDao {
	
	public Replatform_Estimation getReplatformEstimationById(Integer replatformId);	
	
	public boolean addplatformEstimation(Replatform_Estimation estimation);
	
	public boolean updateReplatformEstimation(Replatform_Estimation estimation);
	
	public boolean deleteReplatformEstimation(Integer replatformId);
	
	public List<Replatform_Estimation> getAllReplatformEstimation();
	
	public List<Replatform_Estimation> getReplatformEstByCategory(String category);
	
	public List<Replatform_Estimation> getReplatformEstByCotsTshirtSize(String tshirt);
	
	public List<Replatform_Estimation> getReplatformEstByCustomTshirtSize(String tshirt);

}