package com.cg.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entity.Rehost_Estimation;
import com.cg.entity.Score;



@Transactional
@Repository
public class RehostDaoImpl implements RehostDao {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public Rehost_Estimation getRehostEstimationById(Integer rehostId) {
		Rehost_Estimation estimation = em.find(Rehost_Estimation.class, rehostId);
		return estimation;
	}

	@Override
	public boolean addRehostEstimation(Rehost_Estimation estimation) {
		em.persist(estimation);
		return true;
	}

	@Override
	public boolean updateRehostEstimation(Rehost_Estimation estimation) {
		em.merge(estimation);
		return true;
	}

	@Override
	public boolean deleteRehostEstimation(Integer rehostId) {
		boolean flag =false;
		Rehost_Estimation estimation = em.find(Rehost_Estimation.class, rehostId);
		if(estimation != null)
		{
			em.remove(estimation);
			flag = true;
		}
		
		return flag;
	}

	@Override
	public List<Rehost_Estimation> getAllRehostEstimation() {
		
		String sqlQuery = "from Rehost_Estimation";
		TypedQuery<Rehost_Estimation> query = em.createQuery(sqlQuery, Rehost_Estimation.class);
		List<Rehost_Estimation> estimation = query.getResultList();
		
 		return estimation;
		 
	}

	@Override
	public List<Rehost_Estimation> getRehostByActivities(String activityName) {
		String sqlQuery = "from Rehost_Estimation s where s.activities=:activityName";
		TypedQuery<Rehost_Estimation> query = em.createQuery(sqlQuery, Rehost_Estimation.class);
		query.setParameter("activities", activityName);
		return  query.getResultList();
	}

	@Override
	public List<Rehost_Estimation> getReshostEstByCategory(String category) {
		String sqlQuery = "from Rehost_Estimation r where r.category = :category";
		TypedQuery<Rehost_Estimation> query = em.createQuery(sqlQuery,Rehost_Estimation.class);
		query.setParameter("category", category);
		List<Rehost_Estimation> rehost = query.getResultList();
		return rehost;
	}

	@Override
	public List<Rehost_Estimation> getRehostEstByCotsTshirtSize(String tshirt) {
		String sqlQuery = "from Rehost_Estimation r where r.cots_tshirt_size = :cots_tshirt_size";
		TypedQuery<Rehost_Estimation> query = em.createQuery(sqlQuery,Rehost_Estimation.class);
		query.setParameter("cots_tshirt_size", tshirt);
		List<Rehost_Estimation> rehost = query.getResultList();
		return rehost;
	}

	@Override
	public List<Rehost_Estimation> getRehostEstByCustomTshirtSize(String tshirt) {
		String sqlQuery = "from Rehost_Estimation r where r.custom_tshirt_size = :custom_tshirt_size";
		TypedQuery<Rehost_Estimation> query = em.createQuery(sqlQuery,Rehost_Estimation.class);
		query.setParameter("custom_tshirt_size", tshirt);
		List<Rehost_Estimation> rehost = query.getResultList();
		return rehost;
	}
}