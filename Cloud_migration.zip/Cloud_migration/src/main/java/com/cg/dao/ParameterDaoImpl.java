package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entity.Parameters;

@Repository
@Transactional

public class ParameterDaoImpl implements ParameterDao {

	@PersistenceContext
	private EntityManager em;

	@Override
	public Parameters getParameters(Integer parameterId) {

		Parameters parameters = em.find(Parameters.class, parameterId);
		return parameters;
	}

	@Override
	public List<Parameters> getParameterByTshirtSize(String category) {

		String sqlQuery = "from Parameters p where p.category=:category";
		TypedQuery<Parameters> query = em.createQuery(sqlQuery, Parameters.class);
		query.setParameter("category", category);
		List<Parameters> parameterDetails = query.getResultList();
		return parameterDetails;
	}

	@Override
	public boolean addParameters(Parameters parameter) {
		em.persist(parameter);
		return true;
	}

	@Override
	public boolean updateParameter(Parameters parameter) {
		em.merge(parameter);
		return true;
	}

	@Override
	public boolean deleteParameter(Integer parameterId) {
		Parameters parameter = em.find(Parameters.class, parameterId);
		em.remove(parameter);
		return true;
	}

	@Override
	public List<Parameters> getAllParameters() {
	
		String sqlQuery = "from Parameters";
		
		TypedQuery<Parameters> query = em.createQuery(sqlQuery, Parameters.class);
		List<Parameters> parameterDetails = query.getResultList();
		return parameterDetails;

	}

}
