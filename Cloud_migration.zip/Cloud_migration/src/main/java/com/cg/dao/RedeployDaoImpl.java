package com.cg.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entity.Redeploy_Estimation;
import com.cg.entity.Rehost_Estimation;


@Transactional
@Repository
public class RedeployDaoImpl implements RedeployDao {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public Redeploy_Estimation getRedeployEstimationById(Integer redeployId) {
		Redeploy_Estimation estimation = em.find(Redeploy_Estimation.class, redeployId);
		return estimation;
	}

	@Override
	public boolean addRedeployEstimation(Redeploy_Estimation estimation){
		em.persist(estimation);
		return true;
	}

	@Override
	public boolean updateRedeployEstimation(Redeploy_Estimation estimation) {
		em.merge(estimation);
		return true;
	}

	@Override
	public boolean deleteRedeployEstimation(Integer redeployId) {
		boolean flag =false;
		Redeploy_Estimation estimation = em.find(Redeploy_Estimation.class, redeployId);
		if(estimation != null)
		{
			em.remove(estimation);
			flag = true;
		}	
		return flag;
	}

	@Override
	public List<Redeploy_Estimation> getAllRedeployEstimation() {
		String sqlQuery = "from Redeploy_Estimation";
		TypedQuery<Redeploy_Estimation> query = em.createQuery(sqlQuery, Redeploy_Estimation.class);
		List<Redeploy_Estimation> estimation = query.getResultList();
 		return estimation;
	}

	@Override
	public List<Redeploy_Estimation> getRedeployEstByCategory(String category) {
		String sqlQuery = "from Redeploy_Estimation r where r.category = :category";
		TypedQuery<Redeploy_Estimation> query = em.createQuery(sqlQuery,Redeploy_Estimation.class);
		query.setParameter("category", category);
		List<Redeploy_Estimation> redeploy = query.getResultList();
		return redeploy;
	}

	@Override
	public List<Redeploy_Estimation> getRedeployEstByCotsTshirtSize(String tshirt) {
		String sqlQuery = "from Redeploy_Estimation r where r.cots_tshirt_size = :cots_tshirt_size";
		TypedQuery<Redeploy_Estimation> query = em.createQuery(sqlQuery,Redeploy_Estimation.class);
		query.setParameter("cots_tshirt_size", tshirt);
		List<Redeploy_Estimation> redeploy = query.getResultList();
		return redeploy;
	}

	@Override
	public List<Redeploy_Estimation> getRedeployEstByCustomTshirtSize(String tshirt) {
		String sqlQuery = "from Redeploy_Estimation r where r.custom_tshirt_size = :custom_tshirt_size";
		TypedQuery<Redeploy_Estimation> query = em.createQuery(sqlQuery,Redeploy_Estimation.class);
		query.setParameter("custom_tshirt_size", tshirt);
		List<Redeploy_Estimation> redeploy = query.getResultList();
		return redeploy;	
	}
	
}
