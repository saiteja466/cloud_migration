package com.cg.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entity.Rehost_Estimation;
import com.cg.entity.Replatform_Estimation;

@Transactional
@Repository
public class ReplatformDaoImpl implements ReplatformDao {

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public Replatform_Estimation getReplatformEstimationById(Integer replatformId) {
		Replatform_Estimation estimation = em.find(Replatform_Estimation.class, replatformId);
		return estimation;
	}

	@Override
	public boolean addplatformEstimation(Replatform_Estimation estimation) {
		em.persist(estimation);
		return true;
	}

	@Override
	public boolean updateReplatformEstimation(Replatform_Estimation estimation) {
		em.merge(estimation);
		return true;
	}

	@Override
	public boolean deleteReplatformEstimation(Integer replatformId) {
		boolean flag =false;
		Replatform_Estimation estimation = em.find(Replatform_Estimation.class, replatformId);
		if(estimation != null)
		{
			em.remove(estimation);
			flag = true;
		}
		
		return flag;
	}

	@Override
	public List<Replatform_Estimation> getAllReplatformEstimation() {
		
		String sqlQuery = "from Replatform_Estimation";
		TypedQuery<Replatform_Estimation> query = em.createQuery(sqlQuery, Replatform_Estimation.class);
		List<Replatform_Estimation> estimation = query.getResultList();
 		return estimation;
	}

	@Override
	public List<Replatform_Estimation> getReplatformEstByCategory(String category) {
		String sqlQuery = "from Replatform_Estimation r where r.category = :category";
		TypedQuery<Replatform_Estimation> query = em.createQuery(sqlQuery,Replatform_Estimation.class);
		query.setParameter("category", category);
		List<Replatform_Estimation> replatform = query.getResultList();
		return replatform;
	}

	@Override
	public List<Replatform_Estimation> getReplatformEstByCotsTshirtSize(String tshirt) {
		String sqlQuery = "from Replatform_Estimation r where r.cots_tshirt_size = :cots_tshirt_size";
		TypedQuery<Replatform_Estimation> query = em.createQuery(sqlQuery,Replatform_Estimation.class);
		query.setParameter("cots_tshirt_size", tshirt);
		List<Replatform_Estimation> replatform = query.getResultList();
		return replatform;
	}

	@Override
	public List<Replatform_Estimation> getReplatformEstByCustomTshirtSize(String tshirt) {
		String sqlQuery = "from Replatform_Estimation r where r.custom_tshirt_size = :custom_tshirt_size";
		TypedQuery<Replatform_Estimation> query = em.createQuery(sqlQuery,Replatform_Estimation.class);
		query.setParameter("custom_tshirt_size", tshirt);
		List<Replatform_Estimation> replatform = query.getResultList();
		return replatform;
	}

}
