package com.cg.dao;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.entity.Rehost_Estimation;




@Repository
public interface RehostDao {
	
	public Rehost_Estimation getRehostEstimationById(Integer rehostId);	
	
	public boolean addRehostEstimation(Rehost_Estimation estimation);
	
	public boolean updateRehostEstimation(Rehost_Estimation estimation);
	
	public boolean deleteRehostEstimation(Integer rehostId);
	
	public List<Rehost_Estimation> getAllRehostEstimation();
	
	public List<Rehost_Estimation> getReshostEstByCategory(String category);
	
	
	
	public List<Rehost_Estimation> getRehostEstByCotsTshirtSize(String tshirt);
	
	
	public List<Rehost_Estimation> getRehostEstByCustomTshirtSize(String tshirt);
	
	
	
	public List<Rehost_Estimation> getRehostByActivities(String activityName);

}
