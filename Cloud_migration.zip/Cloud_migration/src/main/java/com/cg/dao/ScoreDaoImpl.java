package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entity.Score;

@Repository
@Transactional
public class ScoreDaoImpl implements ScoreDao {

	@PersistenceContext
	private EntityManager em;

	@Override
	public Score getScoreByScoreId(Integer scoreId) {
		Score score = em.find(Score.class, scoreId);
		return score;
	}

	@Override
	public List<Score> getScoreByApplicationComplexity(String applicationComplexity) {
		String sqlQuery = "from Score s where s.applicationComplexity=:applicationComplexity";
		TypedQuery<Score> query = em.createQuery(sqlQuery, Score.class);
		query.setParameter("applicationComplexity", applicationComplexity);
		List<Score> ScoreDetails = query.getResultList();
		return ScoreDetails;
	}
	
	
	
	@Override
	public Score getScoreByApplicationData(String applicationData) {
		String sqlQuery = "from Score s where s.applicationData=:applicationData";
		TypedQuery<Score> query = em.createQuery(sqlQuery, Score.class);
		query.setParameter("applicationData", applicationData);
		Score ScoreDetails = query.getSingleResult();
		return ScoreDetails;
	}
	
	
	
	@Override
	public boolean addScore(Score score) {
		em.persist(score);
		return true;
	}

	@Override
	public boolean editScore(Score score) {
		em.merge(score);
		return true;
	}

	@Override
	public List<Score> getAllScores() {

		String sqlQuery = "from Score";
		TypedQuery<Score> query = em.createQuery(sqlQuery, Score.class);
		List<Score> scoreDetail = query.getResultList();
		return scoreDetail;
	}

	@Override
	public boolean deleteScoreById(Integer scoreId) {
		Score score = em.find(Score.class, scoreId);
		em.remove(score);
		return true;
	}

}
