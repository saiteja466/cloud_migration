package com.cg.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.entity.Parameters;

@Repository
public interface ParameterDao {
	
	
	public Parameters getParameters(Integer parameterId);
	
	public List<Parameters> getParameterByTshirtSize(String category);
	
	public boolean addParameters(Parameters parameter);
	
	public boolean updateParameter(Parameters parameter);
	
	public boolean deleteParameter(Integer parameterId);
	
	public List<Parameters> getAllParameters();
	
	
	
	

	
}
