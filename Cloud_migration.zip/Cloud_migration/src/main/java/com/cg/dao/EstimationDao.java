package com.cg.dao;

import java.util.List;

import com.cg.entity.Estimation_Template;


public interface EstimationDao {

	public Estimation_Template getEstimations(Integer estimationId );
	
	public boolean addEstimation(Estimation_Template estimation);
	
	public boolean updateEstimation(Estimation_Template estimation);
	
	public boolean deleteEstimation(Integer estimationId);
	
	public List<Estimation_Template> getAllEstimation();
}

