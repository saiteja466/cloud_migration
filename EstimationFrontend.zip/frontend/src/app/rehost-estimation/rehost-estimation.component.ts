import { Component, OnInit } from '@angular/core';
import { RehostEstmation } from '../RehostEstmation';
import { RehostEstimationService } from '../Service/rehost-estimation.service';
import { ConfirmationService, Message, MessageService } from 'primeng/api';

@Component({
  selector: 'app-rehost-estimation',
  templateUrl: './rehost-estimation.component.html',
  providers: [MessageService, ConfirmationService],
  styleUrls: ['./rehost-estimation.component.css']
})
export class RehostEstimationComponent implements OnInit {

  rehostEst: RehostEstmation[];
  cols: any;
  totalRecords: any;
  editedRecords: RehostEstmation[];
  allActivities: any;
  allCategory: any;
  allCustomActivities: any;
  allCotsActivities: any;
  allCotsTshirtSize: any;
  allCustomTshirtSize: any;
  addcategory: any;
  addactivities: any;
  addcots_activities: any;
  addcots_tshirt_size: any;
  addcots_value: any;
  addcustom_activities: any;
  addcustom_tshirt_size: any;
  addcustom_value: any;
  rehostDialog: boolean;
  cloneRehost: { [s: string]: RehostEstmation; } = {};
  first: number = 0;
  page: number;
  rows: number = 10;
  submitted: boolean;
  rehostEsts: RehostEstmation[] = [];
  msgs: Message[];
  message: string;




  constructor(private rehostService: RehostEstimationService, private confirmationService: ConfirmationService, private messageService: MessageService) { }

  ngOnInit(): void {

    this.cols = [
      { field: 'category', header: 'Category' },
      { field: 'activities', header: 'Activities' },
      { field: 'cots_activities', header: 'Cots Activities' },
      { field: 'cots_tshirt_size', header: 'Cots TshirtSize' },
      { field: 'cots_value', header: 'Cots Value' },
      { field: 'custom_activities', header: 'Custom Activities' },
      { field: 'custom_tshirt_size', header: 'Custom TshirtSize' },
      { field: 'custom_value', header: 'Custom Value' }
    ];

    this.allCategory = [
      { label: 'Discovery(PD)', value: 'Discovery(PD)' },
      { label: 'Design Efforts (PD)', value: 'Design Efforts (PD)' },
      { label: 'Execution Efforts (PD)', value: 'Execution Efforts (PD)' },
    ];


    this.allActivities = [
      { label: 'Application Discovery', value: 'Application Discovery' },
      { label: 'Analyze Dependencies & Interfaces', value: 'Analyze Dependencies & Interfaces' },
      { label: 'Pre Migration test prep + Inputs to Infra mig team ', value: ' Pre Migration test prep + Inputs to Infra mig team' },
      { label: 'Coordination with Vendors for COTs ', value: 'Coordination with Vendors for COTs' },
      { label: 'Configuration changes ', value: 'Configuration changes' },


      { label: 'Discovery(PD)', value: 'Discovery(PD)' },
      { label: 'Design Efforts (PD)', value: 'Design Efforts (PD)' },
      { label: 'Execution Efforts (PD)', value: 'Execution Efforts (PD)' }
    ];

    this.allCotsTshirtSize = [
      { label: 'xs', value: 'xs' },
      { label: 's', value: 's' },
      { label: 'm', value: 'm' },
      { label: 'l', value: 'l' },
      { label: 'xl', value: 'xl' }
    ];

    this.allCustomTshirtSize = [
      { label: 'xs', value: 'xs' },
      { label: 's', value: 's' },
      { label: 'm', value: 'm' },
      { label: 'l', value: 'l' },
      { label: 'xl', value: 'xl' }
    ];

    this.allCotsActivities = [
      { label: 'Yes', value: 'Yes' },
      { label: 'No', value: 'No' }
    ];

    this.allCustomActivities = [
      { label: 'Yes', value: 'Yes' },
      { label: 'No', value: 'No' }
    ];
    this.getAllRehost();

  }

  getAllRehost() {
    this.rehostService.getAllRehostEstimations().subscribe(data => {
      console.log("data", data);


      this.rehostEsts = data;
      this.totalRecords = data.length;
    })
  }

  editRehost(rehostEst: any) {
    console.log(rehostEst);
    this.rehostService.editRehostEstimation(this.rehostEsts).subscribe(data => { alert(data) });
  }

  onRowEditInit(rehostEst: any) {

    this.cloneRehost[rehostEst.rehost_id] = { ...rehostEst };
    console.log(rehostEst);
  }

  onRowEditSave(rehostEst: any) {
    this.submitted = true;

    this.editRehost(rehostEst);

    console.log(rehostEst);
  }

  onRowEditCancel(rehost: any, ri: number) {
    this.editedRecords = this.rehostEsts;

    this.editedRecords[ri] = this.cloneRehost[rehost.rehost_id];
    delete this.cloneRehost[rehost.rehost_id];

  }

  hideDialog() {
    this.rehostDialog = false;
    this.submitted = false;
  }


  openDialouge() {

    this.submitted = false;
    this.rehostDialog = true;
    console.log("new");
    this.addcategory = null;
    this.addactivities = null;
    this.addcots_activities = null;
    this.addcots_tshirt_size = null;
    this.addcots_value = null;
    this.addcustom_activities = null;
    this.addcustom_tshirt_size = null;
    this.addcustom_value = null;
  }


  saveRehost() {

    this.submitted = true;
    if ((this.addcategory != null || this.addcategory != undefined)
      && (this.addactivities != null || this.addactivities != undefined)
      && (this.addcots_activities != null || this.addcots_activities != undefined)
      && (this.addcots_tshirt_size != null || this.addcots_tshirt_size != undefined)
      && (this.addcots_value != null || this.addcots_value != undefined)
      && (this.addcustom_activities != null || this.addcustom_activities != undefined)
      && (this.addcustom_tshirt_size != null || this.addcustom_tshirt_size != undefined)
      && (this.addcustom_value != null || this.addcustom_value != undefined)) {
      let reqParam = {
        "category": this.addcategory,
        "activities": this.addactivities,
        "cots_activities": this.addcots_activities,
        "cots_tshirt_size": this.addcots_tshirt_size,
        "cots_value": this.addcots_value,
        "custom_activities": this.addcustom_activities,
        "custom_tshirt_size": this.addcustom_tshirt_size,
        "custom_value": this.addcustom_value
      }

      this.rehostService.saveRehostEstimation(reqParam).subscribe(
        (data: any) => {
          this.getAllRehost();

        });
      this.messageService.add({ severity: 'success', summary: 'Rehost Added', detail: this.message });
      this.rehostDialog = false;
      this.getAllRehost();
    }
  }

  deleteRehost(rehostEst: number) {
    console.log("comp:" + rehostEst);
    this.rehostService.deleteRehostEstimation(rehostEst).subscribe(data => {
      (data)
      this.messageService.add({ severity: 'success', summary: 'Deleted', detail: this.message });
      this.getAllRehost();
    });

  }


  // saveRehost() {
  //   this.submitted = true;
  //   if ((this.addcategory != null || this.addcategory != undefined)
  //     || (this.addactivities != null || this.addactivities != undefined)
  //     || (this.addcots_activities != null || this.addcots_activities != undefined)
  //     || (this.addcots_tshirt_size != null || this.addcots_tshirt_size != undefined)
  //     || (this.addcots_value != null || this.addcots_value != undefined)
  //     || (this.addcustom_activities != null || this.addcustom_activities != undefined)
  //     || (this.addcustom_tshirt_size != null || this.addcustom_tshirt_size != undefined)
  //     || (this.addcustom_value != null || this.addcustom_value != undefined)) {

  //     let reqParam = {
  //       "category": this.addcategory,
  //       "activities": this.addactivities,
  //       "cots_activities": this.addcots_activities,
  //       "cots_tshirt_size": this.addcots_tshirt_size,
  //       "cots_value": this.addcots_value,
  //       "custom_activities": this.addcustom_activities,
  //       "custom_tshirt_size": this.addcustom_tshirt_size,
  //       "custom_value": this.addcustom_value
  //     }

  //     this.rehostService.saveRehostEstimation(reqParam).subscribe(
  //       (data: any) => {
  //         alert(data)
  //       });
  //     this.getAllRehost();
  //     this.messageService.add({ severity: 'success', summary: 'Rehost Added', detail: this.message });
  //     this.rehostDialog = false;
  //   }
  // }
  categoryData() {
    if (this.addcategory == "Discovery(PD)") {
      this.allActivities = [
        { label: 'Application Discovery', value: 'Application Discovery' }
      ]
    }
    else if (this.addcategory == "Design Efforts (PD)") {
      this.allActivities = [
        { label: 'Analyze Dependencies & Interfaces', value: 'Analyze Dependencies & Interfaces' },
        { label: 'Pre Migration test prep + Inputs to Infra mig team ', value: ' Pre Migration test prep + Inputs to Infra mig team' },
        { label: 'Coordination with Vendors for COTs ', value: 'Coordination with Vendors for COTs' }
      ]
    }
    else if (this.addcategory == "Execution Efforts (PD)") {
      this.allActivities = [
        { label: 'Configuration changes ', value: 'Configuration changes' },
        { label: 'Database migration and fixes ', value: 'Database migration and fixes' },
        { label: 'Changes for monitoring and alerting ', value: 'Changes for monitoring and alerting' },
        { label: 'CI-CD set up (no CI-CD effort) ', value: 'CI-CD set up (no CI-CD effort)' },
        { label: 'Changes in jobs, SSIS', value: 'Changes in jobs, SSIS' },
        { label: 'Post Migration Testing Efforts (PD)', value: 'Post Migration Testing Efforts (PD)' },
      ]
    }
    else {
      this.addcategory == null;
    }
  }
}