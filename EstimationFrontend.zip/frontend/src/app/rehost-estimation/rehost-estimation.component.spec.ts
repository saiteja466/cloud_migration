import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RehostEstimationComponent } from './rehost-estimation.component';

describe('RehostEstimationComponent', () => {
  let component: RehostEstimationComponent;
  let fixture: ComponentFixture<RehostEstimationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RehostEstimationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RehostEstimationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
