import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http'
import { RehostEstimationRoutingModule } from './rehost-estimation-routing.module';
import { RehostEstimationComponent } from './rehost-estimation.component';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { TranslateModule } from '@ngx-translate/core';
import { ButtonModule } from 'primeng/button';
import { PaginatorModule } from 'primeng/paginator';
import { CalendarModule } from 'primeng/calendar';
import { MessageModule } from 'primeng/message';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TooltipModule } from 'primeng/tooltip';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { CheckboxModule } from 'primeng/checkbox';
import { MultiSelectModule } from 'primeng/multiselect';
import { TableModule } from 'primeng/table';

@NgModule({

  imports: [
    CommonModule,
    RehostEstimationRoutingModule,
    HttpClientModule,
    FormsModule,
    MultiSelectModule,
    CheckboxModule,
    ToastModule,
    DialogModule,
    TableModule,
    TooltipModule,
    ConfirmDialogModule,
    MessageModule,
    CalendarModule,
    PaginatorModule,
    ButtonModule,
    TranslateModule,
    DropdownModule
  ],
  declarations: [RehostEstimationComponent],
})
export class RehostEstimationModule { }
