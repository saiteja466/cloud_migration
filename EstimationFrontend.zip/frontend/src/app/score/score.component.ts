import { Component, OnInit } from '@angular/core';
import { ConfirmationService, Message, MessageService } from 'primeng/api';
import { Observable } from 'rxjs';
import { Scores } from '../Scores';
import { ScoreServiceService } from '../Service/score-service.service';

@Component({
  selector: 'app-score',
  templateUrl: './score.component.html',
  providers: [MessageService, ConfirmationService],
  styleUrls: ['./score.component.scss']
})
export class ScoreComponent implements OnInit {

  scores: Scores;

  allComplexity: any;
  allData: any;
  score: Scores[];
  totalRecords: any;
  first: number = 0;
  page: number;
  rows: number = 10;
  cols: any;
  submitted: boolean;
  scoreDialog: boolean;
  cloneScore: { [s: string]: Scores; } = {};
  complexityAddValue: any;
  dataAddValue: any;
  scoreAddValue: any;
  msgs: Message[];

  constructor(private scoreService: ScoreServiceService, private confirmationService: ConfirmationService, private messageService: MessageService) {

  }

  ngOnInit() {
    this.cols = [
      { field: 'scoreId', header: 'Score ID' },
      { field: 'applicationComplexity', header: 'Application Complexity' },
      { field: 'applicationData', header: 'Application Data' },
      { field: 'score', header: 'Score' }

    ];


    this.allComplexity = [
      { label: 'No of Interfaces', value: 'No of Interfaces' },
      { label: 'HA/LB', value: 'HA/LB' },
      { label: 'Application Type', value: 'Application Type' },
      { label: 'App Component', value: 'App Component' },
      { label: 'LOC', value: 'LOC' },
      { label: 'Business Criticality', value: 'Business Criticality' },
      { label: 'Prod Servers', value: 'Prod Servers' },
      { label: 'Database Size', value: 'Database Size' },
      { label: 'Database', value: 'Database' },
      { label: 'DatabaseMigrationType', value: 'DatabaseMigrationType' },
      { label: 'Contigency', value: 'Contigency' },
      { label: 'T Shirt Size', value: 'T Shirt Size' },
      { label: 'Migration Type', value: 'Migration Type' },
      { label: 'Database Size', value: 'Database Size' },
    ]

    console.log("score component");
    this.scoreService.getAllScore().subscribe(data => {
      console.log("data", data);


      this.scores = data;
      this.totalRecords = data.length;
    })
  }

  openDialouge() {

    this.submitted = false;
    this.scoreDialog = true;
    console.log("new");
  }

  addScore(score: any) {

  }

  editScore(score: any) {
    console.log(score);
    this.scoreService.editScore(this.scores).subscribe(data => { alert(data) });
  }

  onRowEditInit(score: any) {

    this.cloneScore[score.scoreId] = { ...score };

    console.log(score);
  }

  onRowEditSave(score: any) {
    this.editScore(score);
    console.log(score);
  }

  onRowEditCancel(score: any, ri: number) {
    this.score[ri] = this.cloneScore[score.score];

  }

  deleteScore(score: any) {
    //console.log(score);
    this.confirmationService.confirm({

      message: 'Are you sure you want to delete ' + score.scoreId + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',

      accept: () => {
        console.log(score.scoreId);

        this.score = this.score.filter(val => val.scoreId !== score.scoreId);
        console.log(score);

        this.messageService.add({ severity: 'success', summary: 'Successful', detail: 'Score Deleted', life: 3000 });
      }
    });
    //console.log(score);
  }

  hideDialog() {
    this.scoreDialog = false;
    this.submitted = false;
  }

  saveScore() {
    this.submitted = true;


    let reqParam = {
      "applicationComplexity": this.complexityAddValue,
      "applicationData": this.dataAddValue,
      "score": this.scoreAddValue
    }
    this.scoreService.addScore(reqParam).subscribe(data => { alert(data) }, error =>
      console.log(error));

    console.log(reqParam);
    this.submitted = false;
    this.scoreDialog = false;
  }

  complexityData() {


    if (this.complexityAddValue == "No of Interfaces") {
      this.allData = [
        { label: 'Less than 5', value: 'Less than 5' },
        { label: 'Between 6 and 10', value: 'Between 6 and 10' },
        { label: 'More than 10', value: 'More than 10' }
      ];
    }

    if (this.scores.applicationComplexity == "HA/LB") {
      this.allData = [
        { label: 'No HA/LB', value: 'No HA/LB' },
        { label: 'HA Only or LB Only', value: 'HA Only or LB Only' },
        { label: 'HA and LB', value: 'HA and LB' }
      ];
    }

    if (this.scores.applicationComplexity == "Application Type") {
      this.allData = [
        { label: 'COTS', value: 'COTS' },
        { label: 'Custom', value: 'Custom' }
      ];
    }

    if (this.scores.applicationComplexity == "App Component") {
      this.allData = [
        { label: 'Frontend only', value: 'Frontend only' },
        { label: 'Backend only', value: 'Backend only' },
        { label: 'Client server', value: 'Client server' }
      ];
    }

    if (this.scores.applicationComplexity == "LOC") {
      this.allData = [
        { label: 'Less than 50K', value: 'Less than 50K' },
        { label: 'Between 50K to 500K', value: 'Between 50K to 500K' },
        { label: 'Between 500K to 1000K', value: 'Between 500K to 1000K' }
      ];
    }

    if (this.scores.applicationComplexity == "Business Criticality") {
      this.allData = [
        { label: 'Low', value: 'Low' },
        { label: 'Medium', value: 'Medium' },
        { label: 'High', value: 'High' }
      ];
    }

    if (this.scores.applicationComplexity == "Prod Servers") {
      this.allData = [
        { label: 'Less than 6', value: 'Less than 6' },
        { label: 'Between 7 to 20', value: 'Between 7 to 20' },
        { label: 'More than 20', value: 'More than 20' }
      ];
    }

    if (this.scores.applicationComplexity == "Database Size") {
      this.allData = [
        { label: 'Less than 100GB', value: 'Less than 100GB' },
        { label: 'Between 100 to 500GB', value: 'Between 100 to 500GB' },
        { label: 'Between 500 to 2TB', value: 'Between 500 to 2TB' }
      ];
    }

    if (this.scores.applicationComplexity == "Database") {
      this.allData = [
        { label: 'DB2', value: 'DB2' },
        { label: 'MSSQL', value: 'MSSQL' },
        { label: 'Between 500 to 2TB', value: 'Between 500 to 2TB' },
        { label: 'MSSQL', value: 'MSSQL' },
        { label: 'MongoDB', value: 'MongoDB' },
        { label: 'MYSQL', value: 'MYSQL' },
        { label: 'Oracle', value: 'Oracle' },
        { label: 'Postgre', value: 'Postgre' },
        { label: 'Sybase', value: 'Sybase' },

      ];
    }

    if (this.scores.applicationComplexity == "DatabaseMigrationType") {
      this.allData = [
        { label: 'IaaS', value: 'IaaS' },
        { label: 'PaaS', value: 'PaaS' }
      ];
    }
  }
}