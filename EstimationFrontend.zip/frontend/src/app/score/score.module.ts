import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import { ScoreComponent } from './score.component';
import { ScoreRoutingModule } from './score-routing.module';
import { TableModule } from 'primeng/table';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { TranslateModule } from '@ngx-translate/core';
import { ButtonModule } from 'primeng/button';
import { PaginatorModule } from 'primeng/paginator';
import { CalendarModule } from 'primeng/calendar';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TooltipModule } from 'primeng/tooltip';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { CheckboxModule } from 'primeng/checkbox';

import { MultiSelectModule } from 'primeng/multiselect';
import { HttpClientModule } from '@angular/common/http';


@NgModule({

  imports: [
    CommonModule,
    ScoreRoutingModule,
    TableModule,
    CommonModule,
    FormsModule,
    ButtonModule,
    MultiSelectModule,
    DropdownModule,
    PaginatorModule,
    CalendarModule,
    MessagesModule,
    MessageModule,
    ConfirmDialogModule,
    TooltipModule,
    ToastModule,
    CheckboxModule,

    TranslateModule,
    DialogModule,
    HttpClientModule

  ],
  declarations: [ScoreComponent]
})
export class ScoreModule { }
