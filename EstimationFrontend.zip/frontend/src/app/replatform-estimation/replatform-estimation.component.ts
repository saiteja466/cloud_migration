import { Component, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService, Message, MessageService } from 'primeng/api';
import { ReplatformEstmation } from '../ReplatformEstimation';
import { ReplatformEstimationService } from '../Service/replatform-estimation.service';


@Component({
  selector: 'app-replatform-estimation',
  templateUrl: './replatform-estimation.component.html',
  providers: [MessageService, ConfirmationService],
  styleUrls: ['./replatform-estimation.component.css']
})
export class ReplatformEstimationComponent implements OnInit {
  replatformEst: ReplatformEstmation[];
  replatformEsts: ReplatformEstmation[] = [];
  cols: any;
  totalRecords: any;
  allActivities: any;
  allCategory: any;
  allCustomActivities: any;
  allCotsActivities: any;
  allCotsTshirtSize: any;
  allCustomTshirtSize: any;
  addcategory: any;
  addactivities: any;
  addcots_activities: any;
  addcots_tshirt_size: any;
  addcots_value: any;
  addcustom_activities: any;
  addcustom_tshirt_size: any;
  addcustom_value: any;
  replatformDialog: boolean;
  cloneReplatform: { [s: string]: ReplatformEstmation; } = {};
  first: number = 0;
  page: number;
  rows: number = 10;
  submitted: boolean;
  msgs: Message[];
  message: string;
  editedRecords: ReplatformEstmation[];




  constructor(private replatformService: ReplatformEstimationService, private confirmationService: ConfirmationService, private messageService: MessageService) { }

  ngOnInit(): void {

    this.cols = [
      { field: 'category', header: 'Category' },
      { field: 'activities', header: 'Activities' },
      { field: 'cots_activities', header: 'Cots Activities' },
      { field: 'cots_tshirt_size', header: 'Cots TshirtSize' },
      { field: 'cots_value', header: 'Cots Value' },
      { field: 'custom_activities', header: 'Custom Activities' },
      { field: 'custom_tshirt_size', header: 'Custom TshirtSize' },
      { field: 'custom_value', header: 'Custom Value' }
    ];

    this.allCategory = [
      { label: 'Discovery(PD)', value: 'Discovery(PD)' },
      { label: 'Design Efforts (PD)', value: 'Design Efforts (PD)' },
      { label: 'Build + Testing (PD)', value: 'Build + Testing (PD)' },
    ];

    this.allCotsTshirtSize = [
      { label: 'xs', value: 'xs' },
      { label: 's', value: 's' },
      { label: 'm', value: 'm' },
      { label: 'l', value: 'l' },
      { label: 'xl', value: 'xl' }
    ];

    this.allCustomTshirtSize = [
      { label: 'xs', value: 'xs' },
      { label: 's', value: 's' },
      { label: 'm', value: 'm' },
      { label: 'l', value: 'l' },
      { label: 'xl', value: 'xl' }
    ];

    this.allCotsActivities = [
      { label: 'Yes', value: 'Yes' },
      { label: 'No', value: 'No' }
    ];

    this.allCustomActivities = [
      { label: 'Yes', value: 'Yes' },
      { label: 'No', value: 'No' }
    ];

    this.getAllReplatform();

  }

  getAllReplatform() {
    this.replatformService.getAllReplatfformEstimations().subscribe(data => {
      console.log("data", data);
      this.replatformEsts = data;
      this.totalRecords = data.length;
    })
  }

  editReplatform(replatformEst: any) {
    console.log(replatformEst);
    this.replatformService.editReplatformEstimation(this.replatformEsts).subscribe(data => { alert(data) });
  }

  onRowEditInit(replatformEst: any) {

    this.cloneReplatform[replatformEst.replatform_id] = { ...replatformEst };
    console.log(replatformEst);
  }

  onRowEditSave(replatformEst: any) {
    this.submitted = true;

    this.editReplatform(replatformEst);

    console.log(replatformEst);
  }

  onRowEditCancel(replatform: any, ri: number) {
    this.editedRecords = this.replatformEsts;

    this.editedRecords[ri] = this.cloneReplatform[replatform.replatform_id];
    delete this.cloneReplatform[replatform.replatform_id];

  }

  hideDialog() {
    this.replatformDialog = false;
    this.submitted = false;
  }


  openDialouge() {

    this.submitted = false;
    this.replatformDialog = true;
    console.log("new");
    this.addcategory = null;
    this.addactivities = null;
    this.addcots_activities = null;
    this.addcots_tshirt_size = null;
    this.addcots_value = null;
    this.addcustom_activities = null;
    this.addcustom_tshirt_size = null;
    this.addcustom_value = null;
  }


  saveReplatform() {

    this.submitted = true;
    if ((this.addcategory != null || this.addcategory != undefined)
      && (this.addactivities != null || this.addactivities != undefined)
      && (this.addcots_activities != null || this.addcots_activities != undefined)
      && (this.addcots_tshirt_size != null || this.addcots_tshirt_size != undefined)
      && (this.addcots_value != null || this.addcots_value != undefined)
      && (this.addcustom_activities != null || this.addcustom_activities != undefined)
      && (this.addcustom_tshirt_size != null || this.addcustom_tshirt_size != undefined)
      && (this.addcustom_value != null || this.addcustom_value != undefined)) {
      let reqParam = {
        "category": this.addcategory,
        "activities": this.addactivities,
        "cots_activities": this.addcots_activities,
        "cots_tshirt_size": this.addcots_tshirt_size,
        "cots_value": this.addcots_value,
        "custom_activities": this.addcustom_activities,
        "custom_tshirt_size": this.addcustom_tshirt_size,
        "custom_value": this.addcustom_value
      }

      this.replatformService.saveReplatformEstimation(reqParam).subscribe(
        (data: any) => {
          this.getAllReplatform();

        });
      this.messageService.add({ severity: 'success', summary: 'Replatform Added', detail: this.message });
      this.replatformDialog = false;
      this.getAllReplatform();
    }
  }

  deleteReplatform(replatformEst: number) {
    console.log("comp:" + replatformEst);
    this.replatformService.deleteReplatformEstimation(replatformEst).subscribe(data => {
      (data)
      this.messageService.add({ severity: 'success', summary: 'Deleted', detail: this.message });
      this.getAllReplatform();
    });

  }










  categoryData() {
    if (this.addcategory == "Discovery(PD)") {
      this.allActivities = [
        { label: 'Application Discovery', value: 'Application Discovery' }
      ]
    }
    else if (this.addcategory == "Design Efforts (PD)") {
      this.allActivities = [
        { label: 'Analysis of app factors effecting Replatform', value: 'Analysis of app factors effecting Replatform' },
        { label: 'Analyze Dependencies & Interfaces', value: 'Analyze Dependencies & Interfaces' },
        { label: 'Pre Migration test prep + Inputs to Infra mig team ', value: ' Pre Migration test prep + Inputs to Infra mig team' },
        { label: 'Coordination with Vendors for COTs ', value: 'Coordination with Vendors for COTs' }
      ]
    }
    else if (this.addcategory == "Build + Testing (PD)") {
      this.allActivities = [
        { label: 'App recompile/install & Fix Compatibility issues', value: 'App recompile/install & Fix Compatibility issues' },
        { label: 'OS upgrade related changes', value: 'OS upgrade related changes' },
        { label: 'Configuration changes ', value: 'Configuration changes' },
        { label: 'Database migration and fixes ', value: 'Database migration and fixes' },
        { label: 'Changes for monitoring and alerting ', value: 'Changes for monitoring and alerting' },
        { label: 'Programming language framework upgrades', value: 'Programming language framework upgrades' },
        { label: 'Containerize application (assuming container platform architecture and framework already in place and the application is already compatible)', value: 'Containerize application (assuming container platform architecture and framework already in place and the application is already compatible) ' },
        { label: 'Active directory related changes', value: 'Active directory related changes' },
        { label: 'CI-CD set up (Only for Custom) ', value: 'CI-CD set up (no CI-CD effort)' },
        { label: 'Changes in jobs, SSIS', value: 'Changes in jobs, SSIS' },
        { label: 'Post Migration Testing Efforts (PD)', value: 'Post Migration Testing Efforts (PD)' },
      ]
    }
    else {
      this.addcategory == null;
    }
  }

}