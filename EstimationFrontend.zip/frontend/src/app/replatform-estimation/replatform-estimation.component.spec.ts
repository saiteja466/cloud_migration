import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplatformEstimationComponent } from './replatform-estimation.component';

describe('ReplatformEstimationComponent', () => {
  let component: ReplatformEstimationComponent;
  let fixture: ComponentFixture<ReplatformEstimationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReplatformEstimationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplatformEstimationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
