import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReplatformEstimationComponent } from './replatform-estimation.component';

const routes: Routes = [
  { path: '', component: ReplatformEstimationComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReplatformEstimationRoutingModule { }
