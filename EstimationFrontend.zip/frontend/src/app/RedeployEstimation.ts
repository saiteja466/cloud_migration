import { RedeployEstimationModule } from "./redeploy-estimation/redeploy-estimation.module";

export interface RedeployEstimation {
    redeploy_id: number;
    category: string;
    activities: string;
    cots_activities: string;
    cots_tshirt_size: string;
    cots_value: number;
    custom_activities: string;
    custom_tshirt_size: string;
    custom_value: number;
}