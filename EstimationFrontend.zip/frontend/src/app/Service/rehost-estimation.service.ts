import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class RehostEstimationService {

  constructor(private http: HttpClient) { }

  getAllRehostEstimations(): Observable<any> {
    return this.http.get<any>("http://localhost:8093/getAllRehostEstimation");
  }

  deleteRehostEstimation(rehost: number): Observable<any> {
    return this.http.delete<any>("http://localhost:8093/deleteRehostEstimation/" + rehost);
  }

  editRehostEstimation(rehostEsts: any) {
    console.log("service" + rehostEsts);
    return this.http.post("http://localhost:8093/updateRehostEstimation", rehostEsts[0], { responseType: 'text' });
  }

  saveRehostEstimation(reqParam) {
    console.log(reqParam);
    return this.http.post("http://localhost:8093/addRehostEstimation", reqParam);
  }
}