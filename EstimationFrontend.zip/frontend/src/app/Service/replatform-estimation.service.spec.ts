import { TestBed } from '@angular/core/testing';

import { ReplatformEstimationService } from './replatform-estimation.service';

describe('ReplatformEstimationService', () => {
  let service: ReplatformEstimationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReplatformEstimationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
