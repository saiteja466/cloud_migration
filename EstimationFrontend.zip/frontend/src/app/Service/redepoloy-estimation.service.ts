import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RedepoloyEstimationService {

  constructor(private http: HttpClient) { }

  getAllRedeployEstimations(): Observable<any> {
    return this.http.get<any>("http://localhost:8093/getAllRedeployEstimation");
  }

  deleteRedeployEstimation(redeploy: number): Observable<any> {
    return this.http.delete<any>("http://localhost:8093/deleteRedeployEstimation/" + redeploy);
  }

  editRedeployEstimation(redeployEsts: any) {
    console.log("service" + redeployEsts);
    return this.http.post("http://localhost:8093/updateRedeployEstimation", redeployEsts[0], { responseType: 'text' });
  }

  saveRedeployEstimation(reqParam) {
    console.log(reqParam);
    return this.http.post<any>("http://localhost:8093/addRedeployEstimation", reqParam)
  }

}