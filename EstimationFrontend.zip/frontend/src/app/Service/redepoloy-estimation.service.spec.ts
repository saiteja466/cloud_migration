import { TestBed } from '@angular/core/testing';

import { RedepoloyEstimationService } from './redepoloy-estimation.service';

describe('RedepoloyEstimationService', () => {
  let service: RedepoloyEstimationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RedepoloyEstimationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
