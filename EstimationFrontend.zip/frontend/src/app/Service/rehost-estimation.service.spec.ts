import { TestBed } from '@angular/core/testing';

import { RehostEstimationService } from './rehost-estimation.service';

describe('RehostEstimationService', () => {
  let service: RehostEstimationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RehostEstimationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
