import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedeployEstimationComponent } from './redeploy-estimation.component';

describe('RedeployEstimationComponent', () => {
  let component: RedeployEstimationComponent;
  let fixture: ComponentFixture<RedeployEstimationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RedeployEstimationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RedeployEstimationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
