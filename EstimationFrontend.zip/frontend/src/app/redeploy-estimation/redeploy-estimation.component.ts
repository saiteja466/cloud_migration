import { Component, OnInit, TemplateRef } from '@angular/core';
import { RedeployEstimation } from '../RedeployEstimation';

import { ConfirmationService, Message, MessageService } from 'primeng/api';
import { RedepoloyEstimationService } from '../Service/redepoloy-estimation.service';

@Component({
  selector: 'app-redeploy-estimation',
  templateUrl: './redeploy-estimation.component.html',
  providers: [MessageService, ConfirmationService],
  styleUrls: ['./redeploy-estimation.component.css']
})
export class RedeployEstimationComponent implements OnInit {



  redeployEst: RedeployEstimation[];

  cols: any;
  totalRecords: any;
  allActivities: any;
  allCategory: any;
  allCustomActivities: any;
  allCotsActivities: any;
  allCotsTshirtSize: any;
  allCustomTshirtSize: any;
  addcategory: any;
  addactivities: any;
  addcots_activities: any;
  addcots_tshirt_size: any;
  addcots_value: any;
  addcustom_activities: any;
  addcustom_tshirt_size: any;
  addcustom_value: any;
  redeployDialog: boolean;
  cloneRedeploy: { [s: string]: RedeployEstimation; } = {};
  first: number = 0;
  page: number;
  rows: number = 10;
  submitted: boolean;
  redeployEsts: RedeployEstimation[] = [];
  msgs: Message[];
  message: string;
  editedRecords: RedeployEstimation[];

  constructor(private redeployService: RedepoloyEstimationService, private confirmationService: ConfirmationService, private messageService: MessageService) { }

  ngOnInit(): void {

    this.cols = [
      { field: 'category', header: 'Category' },
      { field: 'activities', header: 'Activities' },
      { field: 'cots_activities', header: 'Cots Activities' },
      { field: 'cots_tshirt_size', header: 'Cots TshirtSize' },
      { field: 'cots_value', header: 'Cots Value' },
      { field: 'custom_activities', header: 'Custom Activities' },
      { field: 'custom_tshirt_size', header: 'Custom TshirtSize' },
      { field: 'custom_value', header: 'Custom Value' }
    ];

    this.allCategory = [
      { label: 'Discovery(PD)', value: 'Discovery(PD)' },
      { label: 'Design Efforts (PD)', value: 'Design Efforts (PD)' },
      { label: 'Execution Efforts (PD)', value: 'Execution Efforts (PD)' },
    ];

    this.allCotsTshirtSize = [
      { label: 'xs', value: 'xs' },
      { label: 's', value: 's' },
      { label: 'm', value: 'm' },
      { label: 'l', value: 'l' },
      { label: 'xl', value: 'xl' }
    ];

    this.allCustomTshirtSize = [
      { label: 'xs', value: 'xs' },
      { label: 's', value: 's' },
      { label: 'm', value: 'm' },
      { label: 'l', value: 'l' },
      { label: 'xl', value: 'xl' }
    ];

    this.allCotsActivities = [
      { label: 'Yes', value: 'Yes' },
      { label: 'No', value: 'No' }
    ];

    this.allCustomActivities = [
      { label: 'Yes', value: 'Yes' },
      { label: 'No', value: 'No' }
    ];

    this.getAllRedeploy();

  }

  getAllRedeploy() {
    this.redeployService.getAllRedeployEstimations().subscribe(data => {
      console.log("data", data);


      this.redeployEsts = data;
      this.totalRecords = data.length;
    })
  }

  editRedeloy(redeployEst: any) {
    console.log(redeployEst);
    this.redeployService.editRedeployEstimation(this.redeployEsts).subscribe(data => { alert(data) });
  }

  onRowEditInit(redeployEst: any) {

    this.cloneRedeploy[redeployEst.redeploy_id] = { ...redeployEst };
    console.log(redeployEst);
  }

  onRowEditSave(redeployEst: any) {
    this.submitted = true;

    this.editRedeloy(redeployEst);

    console.log(redeployEst);
  }

  onRowEditCancel(redeploy: any, ri: number) {
    this.editedRecords = this.redeployEsts;

    this.editedRecords[ri] = this.cloneRedeploy[redeploy.redeploy_id];
    delete this.cloneRedeploy[redeploy.redeploy_id];

  }

  hideDialog() {
    this.redeployDialog = false;
    this.submitted = false;
  }


  openDialouge() {

    this.submitted = false;
    this.redeployDialog = true;
    console.log("new");
    this.addcategory = null;
    this.addactivities = null;
    this.addcots_activities = null;
    this.addcots_tshirt_size = null;
    this.addcots_value = null;
    this.addcustom_activities = null;
    this.addcustom_tshirt_size = null;
    this.addcustom_value = null;
  }


  saveRedeploy() {

    this.submitted = true;
    if ((this.addcategory != null || this.addcategory != undefined)
      && (this.addactivities != null || this.addactivities != undefined)
      && (this.addcots_activities != null || this.addcots_activities != undefined)
      && (this.addcots_tshirt_size != null || this.addcots_tshirt_size != undefined)
      && (this.addcots_value != null || this.addcots_value != undefined)
      && (this.addcustom_activities != null || this.addcustom_activities != undefined)
      && (this.addcustom_tshirt_size != null || this.addcustom_tshirt_size != undefined)
      && (this.addcustom_value != null || this.addcustom_value != undefined)) {
      let reqParam = {
        "category": this.addcategory,
        "activities": this.addactivities,
        "cots_activities": this.addcots_activities,
        "cots_tshirt_size": this.addcots_tshirt_size,
        "cots_value": this.addcots_value,
        "custom_activities": this.addcustom_activities,
        "custom_tshirt_size": this.addcustom_tshirt_size,
        "custom_value": this.addcustom_value
      }

      this.redeployService.saveRedeployEstimation(reqParam).subscribe(
        (data: any) => {
          this.getAllRedeploy();

        });
      this.messageService.add({ severity: 'success', summary: 'Redeploy Added', detail: this.message });
      this.redeployDialog = false;
      this.getAllRedeploy();
    }
  }

  deleteRedeploy(redeployEst: number) {
    console.log("comp:" + redeployEst);
    this.redeployService.deleteRedeployEstimation(redeployEst).subscribe(data => {
      (data)
      this.messageService.add({ severity: 'success', summary: 'Deleted', detail: this.message });
      this.getAllRedeploy();
    });

  }

  categoryData() {
    if (this.addcategory == "Discovery(PD)") {
      this.allActivities = [
        { label: 'Application Discovery', value: 'Application Discovery' }
      ]
    }
    else if (this.addcategory == "Design Efforts (PD)") {
      this.allActivities = [
        { label: 'Analyze Dependencies & Interfaces', value: 'Analyze Dependencies & Interfaces' },
        { label: 'Pre Migration test prep + Inputs to Infra mig team ', value: ' Pre Migration test prep + Inputs to Infra mig team' },
        { label: 'Coordination with Vendors for COTs ', value: 'Coordination with Vendors for COTs' }
      ]
    }
    else if (this.addcategory == "Execution Efforts (PD)") {
      this.allActivities = [
        { label: 'Configuration changes ', value: 'Configuration changes' },
        { label: 'Reinstall application on new infrastructure (VM)', value: 'Reinstall application on new infrastructure (VM)' },
        { label: 'Changes for monitoring and aler ting ', value: 'Changes for monitoring and alerting' },
        { label: 'CI-CD set up (Only for Custom) ', value: 'CI-CD set up (Only for Custom)' },
        { label: 'Changes in jobs, SSIS', value: 'Changes in jobs, SSIS' },
        { label: 'Database discovery', value: 'Database discovery' },
        { label: 'Selective Database migration and fixes      ', value: 'Selective Database migration and fixes' },
        { label: 'Changes for monitoring and alerting      ', value: 'Changes for monitoring and alerting      ' },
        { label: 'Post Migration Testing Efforts (PD)', value: 'Post Migration Testing Efforts (PD)' }
      ]
    }
    else {
      this.addcategory == null;
    }
  }
}