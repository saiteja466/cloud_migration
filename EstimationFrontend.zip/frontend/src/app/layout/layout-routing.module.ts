import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '', component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'score', pathMatch: 'prefix' },
            {
                path: 'score',
                loadChildren: () => import('../score/score.module').then(m => m.ScoreModule)
            },
            { path: 'layout/score', redirectTo: 'score' },




            {
                path: 'rehost-estimation',
                loadChildren: () => import('../rehost-estimation/rehost-estimation.module').then(m => m.RehostEstimationModule)
            },
            { path: 'layout/rehost-estimation', redirectTo: 'rehost-estimation' },


            {
                path: 'replatform-estimation',
                loadChildren: () => import('../replatform-estimation/replatform-estimation.module').then(m => m.ReplatformEstimationModule)
            },
            { path: 'layout/replatform-estimation', redirectTo: 'replatform-estimation' },



            {
                path: 'redeploy-estimation',
                loadChildren: () => import('../redeploy-estimation/redeploy-estimation.module').then(m => m.RedeployEstimationModule)
            },
            { path: 'layout/redeploy-estimation', redirectTo: 'redeploy-estimation' }


        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule { }
